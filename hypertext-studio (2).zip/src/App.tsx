import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { LocalHeader } from './components/LocalHeader';
import { LocationPickerBar } from './components/LocationPickerBar';
import { CreatePostModal } from './components/CreatePostModal';
import { SqlGuideModal } from './components/SqlGuideModal';
import { HtmlSourceModal } from './components/HtmlSourceModal';
import { LogoModal } from './components/LogoModal';
import { 
  LocalPost, 
  supabase, 
  calculateHaversineDistance 
} from './services/supabase';
import { INITIAL_DEMO_POSTS } from './data/mockPosts';
import { 
  PlusCircle, 
  Database, 
  AlertTriangle, 
  MapPin, 
  Filter, 
  Sparkles, 
  Inbox, 
  Upload, 
  Image as ImageIcon,
  CheckCircle2,
  X,
  Trash2,
  Heart,
  MessageCircle,
  Share2,
  Send
} from 'lucide-react';

// 1. Bucket का नाम सिर्फ 'posts-media' use करो, 'post-media' मत use करो।
const BUCKET_NAME = "posts-media";

interface PostComment {
  id: string;
  post_id?: string;
  text: string;
  created_at?: string;
}

interface PostCardItemProps {
  post: LocalPost;
  onDelete: (id: string, mediaUrl?: string) => void;
}

// 1 वीडियो ही चलेगा, बाकी अपने आप बंद
let currentPlayingVideo: HTMLVideoElement | null = null;

function handleVideoPlay(e: Event | React.SyntheticEvent<HTMLVideoElement>) {
  const video = (e.currentTarget || e.target) as HTMLVideoElement;
  if (currentPlayingVideo && currentPlayingVideo !== video) {
    currentPlayingVideo.pause();
  }
  currentPlayingVideo = video;
}

// वीडियो खत्म होने पर रीसेट
function handleVideoEnded(e: Event | React.SyntheticEvent<HTMLVideoElement>) {
  const video = (e.currentTarget || e.target) as HTMLVideoElement;
  video.currentTime = 0;
  video.pause();
  if (currentPlayingVideo === video) {
    currentPlayingVideo = null;
  }
}

// Sub-component for each post card with Like, Comment, and Share
const PostCardItem: React.FC<PostCardItemProps> = ({ post: p, onDelete }) => {
  const [likesCount, setLikesCount] = useState<number>(0);
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [showComments, setShowComments] = useState<boolean>(false);
  const [comments, setComments] = useState<PostComment[]>([]);
  const [commentText, setCommentText] = useState<string>("");
  const [isSendingComment, setIsSendingComment] = useState<boolean>(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  // 1. LIKE & COMMENT data loading
  useEffect(() => {
    let isMounted = true;

    // Check if user previously liked this post in localStorage
    try {
      const likedLocal = localStorage.getItem(`ls_liked_${p.id}`);
      if (likedLocal === 'true') {
        setIsLiked(true);
      }
    } catch (e) {}

    // Load likes count from Supabase 'likes' table
    const fetchLikes = async () => {
      try {
        const { count, error } = await supabase
          .from('likes')
          .select('id', { count: 'exact' })
          .eq('post_id', p.id);

        if (!error && typeof count === 'number' && isMounted) {
          setLikesCount(count);
        }
      } catch (err) {
        // Fallback gracefully
      }
    };

    // Load comments from Supabase 'comments' table
    const fetchComments = async () => {
      try {
        const { data, error } = await supabase
          .from('comments')
          .select('*')
          .eq('post_id', p.id)
          .order('created_at', { ascending: true });

        if (!error && data && isMounted) {
          setComments(data);
        } else {
          try {
            const saved = localStorage.getItem(`ls_comments_${p.id}`);
            if (saved && isMounted) {
              setComments(JSON.parse(saved));
            }
          } catch (e) {}
        }
      } catch (err) {
        try {
          const saved = localStorage.getItem(`ls_comments_${p.id}`);
          if (saved && isMounted) {
            setComments(JSON.parse(saved));
          }
        } catch (e) {}
      }
    };

    fetchLikes();
    fetchComments();

    return () => {
      isMounted = false;
    };
  }, [p.id]);

  // 1. LIKE Click: Toggle like and update count
  const handleToggleLike = async () => {
    if (isLiked) {
      setIsLiked(false);
      setLikesCount((prev) => Math.max(0, prev - 1));
      try {
        localStorage.removeItem(`ls_liked_${p.id}`);
        await supabase.from('likes').delete().eq('post_id', p.id);
      } catch (e) {
        console.warn("Unlike error:", e);
      }
    } else {
      setIsLiked(true);
      setLikesCount((prev) => prev + 1);
      try {
        localStorage.setItem(`ls_liked_${p.id}`, 'true');
        await supabase.from('likes').insert({ post_id: p.id });
      } catch (e) {
        console.warn("Like error:", e);
      }
    }
  };

  // 2. COMMENT Send: Insert into 'comments' table
  const handleSendComment = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!commentText.trim()) return;

    const text = commentText.trim();
    setCommentText("");
    setIsSendingComment(true);

    const tempComment: PostComment = {
      id: `comm_${Date.now()}`,
      post_id: p.id,
      text: text,
      created_at: new Date().toISOString()
    };

    // Update UI immediately
    setComments((prev) => [...prev, tempComment]);
    try {
      const saved = JSON.parse(localStorage.getItem(`ls_comments_${p.id}`) || '[]');
      localStorage.setItem(`ls_comments_${p.id}`, JSON.stringify([...saved, tempComment]));
    } catch (e) {}

    try {
      const { data, error } = await supabase
        .from('comments')
        .insert({ post_id: p.id, text: text })
        .select()
        .single();

      if (!error && data) {
        setComments((prev) => prev.map((c) => (c.id === tempComment.id ? data : c)));
      }
    } catch (err) {
      console.warn("Comment insert error:", err);
    } finally {
      setIsSendingComment(false);
    }
  };

  // 3. SHARE: Web share API or WhatsApp fallback
  const handleShare = () => {
    const postTitle = p.title || "लोकल साथी पोस्ट";
    const postDesc = p.description || "";
    const pageUrl = window.location.href;

    if (navigator.share) {
      navigator.share({
        title: postTitle,
        text: postDesc,
        url: pageUrl
      }).catch((err) => {
        if (err.name !== 'AbortError') {
          const shareUrl = `https://wa.me/?text=${encodeURIComponent(`${postTitle} - ${pageUrl}`)}`;
          window.open(shareUrl, '_blank');
        }
      });
    } else {
      const shareUrl = `https://wa.me/?text=${encodeURIComponent(`${postTitle} - ${pageUrl}`)}`;
      window.open(shareUrl, '_blank');
    }
  };

  const mediaUrl = p.media_url || '';
  const isVideo =
    mediaUrl.includes('.mp4') ||
    mediaUrl.includes('video') ||
    mediaUrl.includes('.mov') ||
    mediaUrl.includes('.webm');

  // स्क्रोल पर ऑटो बंद (IntersectionObserver with threshold 0.5)
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const v = entry.target as HTMLVideoElement;
          if (!entry.isIntersecting) {
            v.pause();
          }
        });
      },
      { threshold: 0.5 }
    );

    observer.observe(video);

    return () => {
      observer.disconnect();
    };
  }, [isVideo, mediaUrl]);

  return (
    <div className="bg-neutral-900 rounded-2xl overflow-hidden border border-neutral-800 shadow-md flex flex-col justify-between">
      {/* 3. Media Render: Video or Image */}
      {mediaUrl ? (
        <div className="w-full bg-black overflow-hidden border-b border-neutral-800 flex items-center justify-center">
          {isVideo ? (
            <video
              ref={videoRef}
              src={mediaUrl}
              controls
              playsInline
              preload="metadata"
              onPlay={handleVideoPlay}
              onEnded={handleVideoEnded}
              className="w-full h-72 object-cover bg-black"
            />
          ) : (
            <img
              src={mediaUrl}
              alt={p.title || "लोकल साथी पोस्ट"}
              className="w-full h-72 object-cover bg-neutral-950"
            />
          )}
        </div>
      ) : null}

      {/* 4. p.title को {p.title} की तरह दिखाओ */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="text-[11px] font-mono font-medium text-orange-400 bg-orange-950/40 px-2 py-0.5 rounded border border-orange-800/40 tabular-nums">
              {p.distance_meters !== undefined && p.distance_meters !== null
                ? p.distance_meters < 1000
                  ? `${Math.round(p.distance_meters)} मीटर दूर`
                  : `${(p.distance_meters / 1000).toFixed(2)} KM दूर`
                : '5 KM दायरा'}
            </span>
          </div>

          <h3 className="text-base font-bold text-white leading-snug">
            {p.title}
          </h3>

          {p.description && (
            <p className="text-xs text-neutral-300 leading-relaxed mt-1">
              {p.description}
            </p>
          )}
        </div>

        <div className="pt-2 flex items-center justify-between text-xs text-neutral-400">
          <span className="font-mono text-[11px] text-neutral-500">
            📍 {p.latitude ? Number(p.latitude).toFixed(3) : '0.000'}°, {p.longitude ? Number(p.longitude).toFixed(3) : '0.000'}°
          </span>

          <button
            onClick={() => onDelete(p.id, p.media_url)}
            className="flex items-center gap-1 text-neutral-500 hover:text-red-400 p-1 rounded hover:bg-neutral-800 transition-colors"
            title="पोस्ट डिलीट करें"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="text-[11px]">डिलीट</span>
          </button>
        </div>
      </div>

      {/* Design: काले कार्ड के नीचे एक हल्की लाइन, फिर 3 बटन बराबर-बराबर। मोबाइल फ्रेंडली। */}
      <div className="border-t border-neutral-800/90 grid grid-cols-3 divide-x divide-neutral-800/80 bg-neutral-900/90 text-xs select-none">
        {/* 1. LIKE Button */}
        <button
          onClick={handleToggleLike}
          className={`py-3 px-2 flex items-center justify-center gap-1.5 font-medium transition-colors ${
            isLiked ? 'text-rose-500' : 'text-neutral-400 hover:text-rose-400'
          }`}
          title="लाइक करें"
        >
          <Heart className={`w-4 h-4 transition-transform active:scale-125 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
          <span className="font-semibold">{likesCount > 0 ? likesCount : 'लाइक'}</span>
        </button>

        {/* 2. COMMENT Button */}
        <button
          onClick={() => setShowComments((prev) => !prev)}
          className={`py-3 px-2 flex items-center justify-center gap-1.5 font-medium transition-colors ${
            showComments ? 'text-orange-400 font-semibold' : 'text-neutral-400 hover:text-orange-400'
          }`}
          title="कमेंट देखें या लिखें"
        >
          <MessageCircle className="w-4 h-4" />
          <span>{comments.length > 0 ? `कमेंट (${comments.length})` : 'कमेंट'}</span>
        </button>

        {/* 3. SHARE Button */}
        <button
          onClick={handleShare}
          className="py-3 px-2 flex items-center justify-center gap-1.5 text-neutral-400 hover:text-emerald-400 font-medium transition-colors"
          title="शेयर करें"
        >
          <Share2 className="w-4 h-4" />
          <span>शेयर</span>
        </button>
      </div>

      {/* COMMENT SECTION (EXPANDABLE) */}
      {showComments && (
        <div className="border-t border-neutral-800 bg-neutral-950/80 p-3 space-y-3">
          {/* List of comments under this post */}
          {comments.length > 0 ? (
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {comments.map((c) => (
                <div
                  key={c.id}
                  className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800/80 text-xs"
                >
                  <p className="text-neutral-200 leading-relaxed break-words">{c.text}</p>
                  <span className="text-[10px] text-neutral-500 font-mono mt-1 block">
                    {c.created_at ? new Date(c.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'अभी'}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-[11px] text-neutral-500 text-center py-1">
              कोई कमेंट नहीं है। पहला कमेंट लिखें!
            </p>
          )}

          {/* Comment Input "कमेंट लिखें..." */}
          <form onSubmit={handleSendComment} className="flex gap-2 items-center">
            <input
              type="text"
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              placeholder="कमेंट लिखें..."
              className="flex-1 bg-neutral-900 border border-neutral-700/80 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 outline-none focus:border-orange-500 transition-colors"
            />
            <button
              type="submit"
              disabled={isSendingComment || !commentText.trim()}
              className="bg-orange-600 hover:bg-orange-500 disabled:opacity-40 text-white px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>भेजें</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

const getSavedDemoPosts = (): LocalPost[] => {
  try {
    const saved = localStorage.getItem('local_sathi_demo_posts');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch (e) {}
  return INITIAL_DEMO_POSTS;
};

export default function App() {
  // Geolocation coordinates (defaulting to Delhi or user live GPS)
  const [currentLat, setCurrentLat] = useState<number | null>(28.6139);
  const [currentLng, setCurrentLng] = useState<number | null>(77.2090);
  const RADIUS_KM = 5; // 5 KM दायरा
  const [gpsStatus, setGpsStatus] = useState<string>('डिफ़ॉल्ट लोकेशन (दिल्ली)');
  const [isDetectingGps, setIsDetectingGps] = useState<boolean>(false);

  // Posts Feed & State
  const [posts, setPosts] = useState<LocalPost[]>([]);
  const [demoPosts, setDemoPosts] = useState<LocalPost[]>(getSavedDemoPosts);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDemoMode, setIsDemoMode] = useState<boolean>(false); // Live Supabase by default with automatic demo fallback
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Inline Quick Post Box states
  const [quickTitle, setQuickTitle] = useState("");
  const [quickFile, setQuickFile] = useState<File | null>(null);
  const [quickPreview, setQuickPreview] = useState<string | null>(null);
  const [isQuickUploading, setIsQuickUploading] = useState(false);

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isSqlGuideOpen, setIsSqlGuideOpen] = useState(false);
  const [isHtmlSourceOpen, setIsHtmlSourceOpen] = useState(false);
  const [isLogoModalOpen, setIsLogoModalOpen] = useState(false);

  // Load Posts from Supabase RPC / Table or fallback to demo
  const loadPosts = useCallback(async (lat: number, lng: number) => {
    setIsLoading(true);
    setErrorMessage(null);

    // If Demo Mode is explicitly on
    if (isDemoMode) {
      const radiusMeters = RADIUS_KM * 1000;
      const filtered = demoPosts
        .map((p) => {
          const dist = calculateHaversineDistance(lat, lng, p.latitude, p.longitude);
          return { ...p, distance_meters: dist };
        })
        .filter((p) => p.distance_meters <= radiusMeters)
        .sort((a, b) => (a.distance_meters || 0) - (b.distance_meters || 0));

      setPosts(filtered);
      setIsLoading(false);
      return;
    }

    try {
      // 1. RPC get_nearby_posts call
      const { data, error } = await supabase.rpc('get_nearby_posts', {
        user_lat: lat,
        user_lng: lng,
        radius_meters: 5000, // 5KM
      });

      if (!error && data && data.length > 0) {
        setPosts(data);
        setIsLoading(false);
        return;
      }

      // 2. Direct table fallback if RPC is empty or table query
      const { data: fb, error: fbError } = await supabase
        .from('posts')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(30);

      if (!fbError && fb && fb.length > 0) {
        const withDist = fb.map((p: any) => ({
          ...p,
          distance_meters: calculateHaversineDistance(lat, lng, p.latitude || lat, p.longitude || lng),
        }));
        setPosts(withDist);
      } else {
        // Fallback to sample demo posts if database is empty
        const radiusMeters = RADIUS_KM * 1000;
        const demoFiltered = demoPosts
          .map((p) => ({
            ...p,
            distance_meters: calculateHaversineDistance(lat, lng, p.latitude, p.longitude),
          }))
          .filter((p) => p.distance_meters <= radiusMeters);
        setPosts(demoFiltered);
      }
    } catch (err: any) {
      console.warn("loadPosts error:", err.message);
      setErrorMessage(err.message || 'डेटाबेस कनेक्ट नहीं हो पाया।');
      setPosts(demoPosts);
    } finally {
      setIsLoading(false);
    }
  }, [isDemoMode, demoPosts]);

  // Initial load
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => {
          const lat = p.coords.latitude;
          const lng = p.coords.longitude;
          setCurrentLat(lat);
          setCurrentLng(lng);
          setGpsStatus(`लाइव GPS: ${lat.toFixed(4)}°, ${lng.toFixed(4)}°`);
          loadPosts(lat, lng);
        },
        () => {
          loadPosts(28.6139, 77.2090);
        }
      );
    } else {
      loadPosts(28.6139, 77.2090);
    }
  }, []);

  // When coordinates or demoMode changes
  useEffect(() => {
    if (currentLat !== null && currentLng !== null) {
      loadPosts(currentLat, currentLng);
    }
  }, [currentLat, currentLng, isDemoMode, loadPosts]);

  // 1 वीडियो ही चलेगा, बाकी अपने आप बंद
  // स्क्रोल पर ऑटो बंद (threshold 0.5)
  // वीडियो खत्म होने पर रीसेट
  useEffect(() => {
    // स्क्रोल पर ऑटो बंद
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        const video = entry.target as HTMLVideoElement;
        if (!entry.isIntersecting) {
          video.pause();
        }
      });
    }, { threshold: 0.5 });

    const onPlay = (e: Event) => {
      handleVideoPlay(e);
    };

    const onEnded = (e: Event) => {
      handleVideoEnded(e);
    };

    const setupVideos = () => {
      document.querySelectorAll('video').forEach(v => {
        v.removeEventListener('play', onPlay);
        v.addEventListener('play', onPlay);
        observer.observe(v);

        // वीडियो खत्म होने पर रीसेट
        v.removeEventListener('ended', onEnded);
        v.addEventListener('ended', onEnded);
      });
    };

    setupVideos();

    const mutationObserver = new MutationObserver(() => {
      setupVideos();
    });

    mutationObserver.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      mutationObserver.disconnect();
      document.querySelectorAll('video').forEach(v => {
        v.removeEventListener('play', onPlay);
        v.removeEventListener('ended', onEnded);
      });
    };
  }, [posts]);

  // GPS Detection Button Handler
  const handleDetectGps = () => {
    if (!navigator.geolocation) {
      alert('आपके ब्राउज़र में जीपीएस सपोर्ट उपलब्ध नहीं है।');
      return;
    }

    setIsDetectingGps(true);
    setGpsStatus('लाइव जीपीएस सिग्नल खोजा जा रहा है...');

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        setCurrentLat(lat);
        setCurrentLng(lng);
        setIsDetectingGps(false);
        setGpsStatus(`लाइव जीपीएस कनेक्टेड (${lat.toFixed(4)}°, ${lng.toFixed(4)}°)`);
      },
      (err) => {
        setIsDetectingGps(false);
        setGpsStatus('जीपीएस परमिशन नहीं मिली (डिफ़ॉल्ट सक्रिय)');
        alert(`लोकेशन परमिशन एरर: ${err.message}। आप नीचे परीक्षण शहरों में से चुन सकते हैं।`);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const handleSelectCity = (lat: number, lng: number) => {
    setCurrentLat(lat);
    setCurrentLng(lng);
    setGpsStatus(`परीक्षण लोकेशन: ${lat.toFixed(4)}°, ${lng.toFixed(4)}°`);
  };

  // Inline Quick File Picker (Handles photos & videos up to 80MB)
  const handleQuickFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 80 * 1024 * 1024) {
      alert("80MB से छोटी फाइल लो");
      return;
    }
    setQuickFile(f);
    setQuickPreview(URL.createObjectURL(f));
  };

  // 1 & 2. Inline Quick Post Upload using strictly 'posts-media' bucket and publicUrl
  const handleQuickUpload = async () => {
    if (!quickFile && !quickPreview) {
      alert("गैलरी से फोटो/वीडियो चुनो");
      return;
    }

    setIsQuickUploading(true);
    const postTitle = quickTitle.trim() || "लोकल साथी पोस्ट";
    const postLat = currentLat || 28.6139;
    const postLng = currentLng || 77.2090;

    try {
      let finalMediaUrl = quickPreview || "";

      // 1. Bucket का नाम सिर्फ 'posts-media' use करो, 'post-media' मत use करो।
      if (quickFile) {
        const fileName = `${Date.now()}_${quickFile.name.replace(/\s/g, '_')}`;
        
        const { error: upErr } = await supabase.storage
          .from(BUCKET_NAME)
          .upload(fileName, quickFile);

        if (upErr) {
          console.warn("Storage upload warning:", upErr.message);
          // If storage fails, fallback to local preview
        } else {
          // 2. Upload के बाद supabase.storage.from('posts-media').getPublicUrl(fileName).data.publicUrl से public URL निकालो।
          const { data } = supabase.storage
            .from(BUCKET_NAME)
            .getPublicUrl(fileName);

          if (data?.publicUrl) {
            finalMediaUrl = data.publicUrl;
          }
        }
      }

      // Supabase 'posts' table insert (with category fallback)
      let { data: inserted, error: dbErr } = await supabase
        .from('posts')
        .insert({
          title: postTitle,
          media_url: finalMediaUrl,
          latitude: postLat,
          longitude: postLng,
          category: 'general'
        })
        .select()
        .single();

      // यदि 'category' कॉलम नहीं मिला, तो बिना category के पुनः प्रयास करें
      if (dbErr && (dbErr.message?.toLowerCase().includes('category') || dbErr.message?.includes('schema cache'))) {
        console.warn("डेटाबेस में category कॉलम नहीं मिला, बिना category के री-ट्राई कर रहे हैं...");
        const retryResult = await supabase
          .from('posts')
          .insert({
            title: postTitle,
            media_url: finalMediaUrl,
            latitude: postLat,
            longitude: postLng
          })
          .select()
          .single();
        inserted = retryResult.data;
        dbErr = retryResult.error;
      }

      if (dbErr) {
        console.warn("डेटाबेस इंसर्ट एरर, स्थानीय रूप से दिखा रहे हैं:", dbErr.message);
      }

      // Add to feed immediately with the public URL
      const newPost: LocalPost = {
        id: inserted?.id || `post-${Date.now()}`,
        title: postTitle,
        media_url: finalMediaUrl,
        latitude: postLat,
        longitude: postLng,
        category: 'general',
        created_at: new Date().toISOString(),
        distance_meters: 0
      };

      setPosts((prev) => [newPost, ...prev]);
      setDemoPosts((prev) => [newPost, ...prev]);
      try {
        localStorage.setItem('local_sathi_demo_posts', JSON.stringify([newPost, ...demoPosts].slice(0, 30)));
      } catch (e) {}

      alert("जय माताजी! पोस्ट हो गई");
      setQuickFile(null);
      setQuickPreview(null);
      setQuickTitle("");
      loadPosts(postLat, postLng);
    } catch (err: any) {
      alert("Error: " + err.message + " - posts-media में Policy 2 लगी है क्या देख लो");
    } finally {
      setIsQuickUploading(false);
    }
  };

  // Delete post handler
  const handleDeletePost = async (postId: string, mediaUrl?: string) => {
    if (!confirm('क्या आप सचमुच इस पोस्ट को हटाना चाहते हैं?')) return;

    // Remove from UI immediately
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    setDemoPosts((prev) => prev.filter((p) => p.id !== postId));
    try {
      const updated = demoPosts.filter((p) => p.id !== postId);
      localStorage.setItem('local_sathi_demo_posts', JSON.stringify(updated));
    } catch (e) {}

    try {
      // 1. Bucket 'posts-media' से फाइल डिलीट करें
      if (mediaUrl && !mediaUrl.startsWith('http') && !mediaUrl.startsWith('blob:') && !mediaUrl.startsWith('data:')) {
        await supabase.storage.from(BUCKET_NAME).remove([mediaUrl]);
      } else if (mediaUrl && mediaUrl.includes(BUCKET_NAME)) {
        const parts = mediaUrl.split(`/${BUCKET_NAME}/`);
        if (parts.length > 1) {
          await supabase.storage.from(BUCKET_NAME).remove([decodeURIComponent(parts[1])]);
        }
      }

      // 2. 'posts' टेबल से रिकॉर्ड हटाएं
      await supabase.from('posts').delete().eq('id', postId);
      alert('पोस्ट सफलतापूर्वक हटा दिया गया!');
    } catch (err: any) {
      console.warn("Delete error:", err.message);
    }
  };

  const handlePostCreated = (newPost: LocalPost) => {
    setPosts((prev) => [newPost, ...prev]);
    setDemoPosts((prev) => [newPost, ...prev]);
  };

  // Filtered posts based on category
  const filteredPosts = useMemo(() => {
    if (selectedCategory === 'all') return posts;
    return posts.filter((p) => p.category === selectedCategory);
  }, [posts, selectedCategory]);

  return (
    <div className="min-h-screen bg-black text-neutral-100 flex flex-col font-sans selection:bg-orange-600 selection:text-white">
      {/* Header with LS Logo and actions */}
      <LocalHeader
        currentLat={currentLat}
        currentLng={currentLng}
        radiusKm={RADIUS_KM}
        onRefresh={() => {
          if (currentLat && currentLng) loadPosts(currentLat, currentLng);
        }}
        onOpenCreateModal={() => setIsCreateModalOpen(true)}
        onOpenSqlGuide={() => setIsSqlGuideOpen(true)}
        onOpenHtmlSource={() => setIsHtmlSourceOpen(true)}
        onOpenLogoModal={() => setIsLogoModalOpen(true)}
        isLoading={isLoading}
        isDemoMode={isDemoMode}
        setIsDemoMode={setIsDemoMode}
      />

      {/* Location Bar with 5KM indicator */}
      <LocationPickerBar
        currentLat={currentLat}
        currentLng={currentLng}
        radiusKm={RADIUS_KM}
        onDetectGps={handleDetectGps}
        onSelectCity={handleSelectCity}
        gpsStatus={gpsStatus}
        isDetecting={isDetectingGps}
        totalFound={filteredPosts.length}
      />

      {/* Main Feed Content Area */}
      <main className="flex-1 max-w-4xl mx-auto w-full p-4 sm:p-6 space-y-6">
        {/* INLINE QUICK POST CREATION BOX */}
        <div className="p-4 sm:p-5 bg-neutral-900 rounded-2xl border border-orange-600 shadow-xl shadow-orange-950/20 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm sm:text-base font-bold text-orange-500 flex items-center gap-2">
              <PlusCircle className="w-5 h-5 text-orange-500" />
              <span>📍 लोकल साथी - 5KM पोस्ट शेयर करें</span>
            </h2>
            <span className="text-[11px] font-mono text-neutral-400 bg-neutral-950 px-2.5 py-0.5 rounded-full border border-neutral-800">
              बकेट: posts-media (Max 80MB)
            </span>
          </div>

          <input
            value={quickTitle}
            onChange={(e) => setQuickTitle(e.target.value)}
            placeholder="क्या बताना है?"
            className="w-full p-3 rounded-xl bg-neutral-800 border border-neutral-700 text-sm text-white placeholder-neutral-400 outline-none focus:border-orange-500 transition-colors"
          />

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <label className="flex-1 cursor-pointer flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-dashed border-neutral-700 hover:border-orange-500 bg-neutral-950 text-xs text-neutral-300 transition-colors">
              <Upload className="w-4 h-4 text-orange-400" />
              <span className="truncate">
                {quickFile ? quickFile.name : "गैलरी से फोटो या वीडियो चुनो"}
              </span>
              <input
                type="file"
                accept="image/*,video/*"
                onChange={handleQuickFileChange}
                className="hidden"
              />
            </label>

            {quickPreview && (
              <button
                type="button"
                onClick={() => {
                  setQuickFile(null);
                  setQuickPreview(null);
                }}
                className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-white"
                title="हटाएं"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Preview Box before uploading */}
          {quickPreview && (
            <div className="mt-3 rounded-xl overflow-hidden border border-neutral-700 bg-black aspect-video max-h-72 flex items-center justify-center">
              {quickFile?.type.startsWith('video') || quickPreview.includes('video') ? (
                <video
                  src={quickPreview}
                  controls
                  playsInline
                  onPlay={handleVideoPlay}
                  onEnded={handleVideoEnded}
                  className="w-full h-full max-h-72 object-contain"
                />
              ) : (
                <img
                  src={quickPreview}
                  alt="प्रिव्यू"
                  className="w-full h-full max-h-72 object-contain"
                />
              )}
            </div>
          )}

          <button
            onClick={handleQuickUpload}
            disabled={isQuickUploading}
            className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-orange-950/40 transition-all disabled:opacity-50 text-sm"
          >
            {isQuickUploading ? "अपलोड हो रहा है..." : "पोस्ट शेयर करो"}
          </button>
        </div>

        {/* Category Filters Bar */}
        <div className="flex items-center justify-between gap-3 flex-wrap pt-1">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: 'सभी पोस्ट' },
              { id: 'market', label: 'लोकल मंडी' },
              { id: 'event', label: 'कार्यक्रम व सभा' },
              { id: 'alert', label: 'आवश्यक अलर्ट' },
              { id: 'general', label: 'सामान्य' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-neutral-100 text-neutral-900 font-semibold shadow-sm'
                    : 'bg-neutral-900 text-neutral-400 hover:text-white border border-neutral-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="text-xs text-neutral-400">
            दायरा: <span className="text-orange-400 font-bold font-mono">5 KM</span>
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map((n) => (
              <div
                key={n}
                className="bg-neutral-900 border border-neutral-800 rounded-2xl p-4 animate-pulse space-y-3 h-72"
              >
                <div className="w-full h-44 bg-neutral-800 rounded-xl" />
                <div className="h-4 bg-neutral-800 rounded w-3/4" />
                <div className="h-3 bg-neutral-800 rounded w-1/2" />
              </div>
            ))}
          </div>
        )}

        {/* Empty State */}
        {!isLoading && filteredPosts.length === 0 && (
          <div className="text-center py-16 px-4 rounded-2xl bg-neutral-900/40 border border-neutral-800/80 space-y-4 max-w-md mx-auto">
            <div className="w-12 h-12 rounded-full bg-neutral-800 text-orange-400 mx-auto flex items-center justify-center">
              <Inbox className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                5 KM के दायरे में अभी कोई पोस्ट नहीं मिला
              </h3>
              <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                ऊपर दिए गए बॉक्स से अपनी पहली फ़ोटो या वीडियो शेयर करें!
              </p>
            </div>
          </div>
        )}

        {/* 3 & 4. FEED में पोस्ट दिखाते वक़्त: Like, Comment, Share बटनों के साथ पोस्ट कार्ड्स */}
        {!isLoading && filteredPosts.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
            {filteredPosts.map((p) => (
              <PostCardItem
                key={p.id}
                post={p}
                onDelete={handleDeletePost}
              />
            ))}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800 py-6 px-4 bg-neutral-900/50 text-center text-xs text-neutral-500 mt-12 space-y-2">
        <p>
          📍 <strong>लोकल साथी (Local Saathi)</strong> — 5 किलोमीटर हाइपरलोकल कम्युनिटी फ़ीड नेटवर्क
        </p>
        <div className="flex items-center justify-center gap-4 text-[11px] text-neutral-400 flex-wrap">
          <button onClick={() => setIsLogoModalOpen(true)} className="hover:text-white underline text-amber-400">
            🎨 'LS' ब्रांड लोगो देखें
          </button>
          <span>·</span>
          <button onClick={() => setIsSqlGuideOpen(true)} className="hover:text-white underline">
            Supabase SQL माइग्रेशन
          </button>
          <span>·</span>
          <button onClick={() => setIsHtmlSourceOpen(true)} className="hover:text-white underline">
            स्टैंडअलोन HTML फ़ाइल
          </button>
          <span>·</span>
          <button onClick={handleDetectGps} className="hover:text-white underline">
            लाइव जीपीएस री-चेक
          </button>
        </div>
      </footer>

      {/* Modals */}
      <CreatePostModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        currentLat={currentLat}
        currentLng={currentLng}
        onPostCreated={handlePostCreated}
        isDemoMode={isDemoMode}
      />

      <SqlGuideModal
        isOpen={isSqlGuideOpen}
        onClose={() => setIsSqlGuideOpen(false)}
      />

      <HtmlSourceModal
        isOpen={isHtmlSourceOpen}
        onClose={() => setIsHtmlSourceOpen(false)}
      />

      <LogoModal
        isOpen={isLogoModalOpen}
        onClose={() => setIsLogoModalOpen(false)}
      />
    </div>
  );
}
