import React, { useState } from 'react';
import { 
  X, 
  Upload, 
  MapPin, 
  Image as ImageIcon, 
  Video, 
  Check, 
  AlertCircle,
  Sparkles
} from 'lucide-react';
import { LocalPost, supabase } from '../services/supabase';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLat: number | null;
  currentLng: number | null;
  onPostCreated: (post: LocalPost) => void;
  isDemoMode: boolean;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  isOpen,
  onClose,
  currentLat,
  currentLng,
  onPostCreated,
  isDemoMode,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<'general' | 'market' | 'event' | 'alert'>('general');
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string | null>(null);
  const [customLat, setCustomLat] = useState<number>(currentLat || 28.6139);
  const [customLng, setCustomLng] = useState<number>(currentLng || 77.2090);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMediaFile(file);
      const url = URL.createObjectURL(file);
      setMediaPreview(url);
    }
  };

  const handleSelectSampleImage = (url: string) => {
    setMediaPreview(url);
    setMediaFile(null); // Indicates remote sample
  };

  const sampleImages = [
    { label: 'मंडी/सब्जियां', url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80' },
    { label: 'पार्क/सभा', url: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=800&q=80' },
    { label: 'सड़क/यातायात', url: 'https://images.unsplash.com/photo-1584467735871-8e85353a8413?auto=format&fit=crop&w=800&q=80' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('कृपया पोस्ट का शीर्षक दर्ज करें।');
      return;
    }

    try {
      setIsSubmitting(true);
      setErrorMsg(null);

      let storedMediaUrl = mediaPreview || '';

      if (!isDemoMode && mediaFile) {
        // Upload to Supabase Storage bucket 'posts-media'
        const fileExt = mediaFile.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2, 8)}.${fileExt}`;
        const filePath = `uploads/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('posts-media')
          .upload(filePath, mediaFile);

        if (uploadError) {
          console.warn('Storage upload warning:', uploadError.message);
        } else {
          const { data } = supabase.storage.from('posts-media').getPublicUrl(filePath);
          if (data?.publicUrl) {
            storedMediaUrl = data.publicUrl;
          }
        }
      }

      if (!isDemoMode) {
        // Insert into Supabase table 'posts'
        let insertResult = await supabase
          .from('posts')
          .insert([
            {
              title,
              description,
              media_url: storedMediaUrl,
              latitude: customLat,
              longitude: customLng,
              category,
            },
          ])
          .select()
          .single();

        // यदि 'category' कॉलम नहीं मिला, तो बिना category के पुनः प्रयास करें
        if (insertResult.error && (insertResult.error.message?.toLowerCase().includes('category') || insertResult.error.message?.includes('schema cache'))) {
          console.warn("डेटाबेस में category कॉलम नहीं मिला, बिना category के री-ट्राई कर रहे हैं...");
          insertResult = await supabase
            .from('posts')
            .insert([
              {
                title,
                description,
                media_url: storedMediaUrl,
                latitude: customLat,
                longitude: customLng,
              },
            ])
            .select()
            .single();
        }

        if (insertResult.data) {
          onPostCreated(insertResult.data);
          onClose();
          return;
        }

        if (insertResult.error) {
          console.warn("Supabase insert fallback:", insertResult.error.message);
          // Fallback to local post so user is never blocked
        }
      }

      // Demo Mode or Fallback Mode
      const newPost: LocalPost = {
        id: `local-${Date.now()}`,
        title,
        description,
        media_url: storedMediaUrl,
        latitude: customLat,
        longitude: customLng,
        category,
        created_at: new Date().toISOString(),
      };

      onPostCreated(newPost);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'पोस्ट अपलोड करने में त्रुटि आई।');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-600/20 text-orange-400 border border-orange-500/30 flex items-center justify-center font-bold">
              +
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                नया लोकल पोस्ट जोड़ें
              </h2>
              <p className="text-xs text-neutral-400">
                अपने 5KM दायरे के पड़ोसियों के साथ जानकारी साझा करें।
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-red-950/40 border border-red-800/50 text-red-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              पोस्ट का शीर्षक *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="उदा. मेन मार्केट में नया मेडिकल स्टोर खुला"
              className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-lg text-sm text-white placeholder-neutral-500 outline-none focus:border-orange-500 transition-colors"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              श्रेणी (Category)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'general', label: 'सामान्य' },
                { id: 'market', label: 'लोकल मंडी' },
                { id: 'event', label: 'कार्यक्रम' },
                { id: 'alert', label: 'अलर्ट' },
              ].map((c) => (
                <button
                  type="button"
                  key={c.id}
                  onClick={() => setCategory(c.id as any)}
                  className={`py-2 px-2 rounded-lg text-xs font-medium border transition-colors ${
                    category === c.id
                      ? 'bg-orange-600/20 text-orange-400 border-orange-500'
                      : 'bg-neutral-950 text-neutral-400 border-neutral-800 hover:text-neutral-200'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1">
              विवरण (Description)
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="विस्तार से बताएं कि क्या, कब और कहाँ हो रहा है..."
              className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-lg text-xs text-white placeholder-neutral-500 outline-none focus:border-orange-500 transition-colors"
            />
          </div>

          {/* Media Upload */}
          <div>
            <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
              फ़ोटो या वीडियो जोड़ें
            </label>

            <div className="flex flex-col gap-2">
              <label className="border-2 border-dashed border-neutral-800 hover:border-orange-500/50 rounded-xl p-4 text-center cursor-pointer transition-colors bg-neutral-950/60 block">
                <input
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <Upload className="w-5 h-5 text-neutral-500 mx-auto mb-1" />
                <span className="text-xs text-neutral-300 font-medium block">
                  डिवाइस से फ़ोटो/वीडियो चुनें
                </span>
                <span className="text-[11px] text-neutral-500">
                  PNG, JPG, MP4 (अधिकतम 15MB)
                </span>
              </label>

              {/* Sample Photo Pickers for easy testing */}
              <div className="flex items-center gap-1.5 pt-1">
                <span className="text-[11px] text-neutral-500">त्वरित नमूना:</span>
                {sampleImages.map((s) => (
                  <button
                    type="button"
                    key={s.label}
                    onClick={() => handleSelectSampleImage(s.url)}
                    className="text-[11px] px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 hover:text-white"
                  >
                    {s.label}
                  </button>
                ))}
              </div>

              {mediaPreview && (
                <div className="relative aspect-video rounded-lg overflow-hidden border border-neutral-800 mt-1 bg-black">
                  <img
                    src={mediaPreview}
                    alt="Preview"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setMediaFile(null);
                      setMediaPreview(null);
                    }}
                    className="absolute top-2 right-2 p-1 rounded-full bg-black/70 text-white hover:bg-black"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* GPS Coordinates attached */}
          <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-neutral-400">
              <MapPin className="w-4 h-4 text-orange-400" />
              <span>पोस्ट की लोकेशन:</span>
            </div>
            <div className="font-mono text-neutral-200 tabular-nums">
              {customLat.toFixed(4)}° N, {customLng.toFixed(4)}° E
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 transition-colors"
            >
              रद्द करें
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 rounded-lg text-xs font-semibold text-white bg-orange-600 hover:bg-orange-500 shadow-md shadow-orange-950/40 transition-colors disabled:opacity-50"
            >
              {isSubmitting ? 'पोस्ट हो रहा है...' : 'अभी पोस्ट करें'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
