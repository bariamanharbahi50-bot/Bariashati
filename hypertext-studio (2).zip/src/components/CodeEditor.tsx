import React, { useRef, useState } from 'react';
import { 
  Copy, 
  Check, 
  Wand2, 
  Minimize2, 
  RotateCcw, 
  Plus, 
  FileCode, 
  ChevronRight,
  Terminal
} from 'lucide-react';
import { formatHtml, minifyHtml } from '../utils/htmlFormatter';

interface CodeEditorProps {
  code: string;
  onChange: (value: string) => void;
  onInsertSnippet?: (snippet: string) => void;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ code, onChange }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [copied, setCopied] = useState(false);
  const [activeSnippetCategory, setActiveSnippetCategory] = useState<'layout' | 'content' | 'form' | 'interactive'>('layout');

  const lines = code.split('\n');
  const lineCount = lines.length;
  const charCount = code.length;
  const byteCount = new Blob([code]).size;

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const handleFormat = () => {
    const formatted = formatHtml(code);
    onChange(formatted);
  };

  const handleMinify = () => {
    const minified = minifyHtml(code);
    onChange(minified);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const textarea = textareaRef.current;
      if (!textarea) return;

      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;

      const updated = code.substring(0, start) + '  ' + code.substring(end);
      onChange(updated);

      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + 2;
      }, 0);
    }
  };

  const insertSnippet = (snippet: string) => {
    const textarea = textareaRef.current;
    if (!textarea) {
      onChange(code + '\n' + snippet);
      return;
    }

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const updated = code.substring(0, start) + snippet + code.substring(end);
    onChange(updated);

    setTimeout(() => {
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = start + snippet.length;
    }, 0);
  };

  const quickSnippets = {
    layout: [
      { label: '<header>', code: '<header>\n  <h1>Site Title</h1>\n  <nav>\n    <a href="#home">Home</a>\n  </nav>\n</header>' },
      { label: '<main>', code: '<main>\n  <section>\n    <h2>Main Section</h2>\n    <p>Content...</p>\n  </section>\n</main>' },
      { label: '<section>', code: '<section id="features">\n  <h2>Features</h2>\n</section>' },
      { label: '<article>', code: '<article>\n  <h2>Story Title</h2>\n  <p>Article narrative...</p>\n</article>' },
      { label: '<aside>', code: '<aside>\n  <h3>Related Links</h3>\n</aside>' },
      { label: '<footer>', code: '<footer>\n  <p>&copy; 2026 Brand. Built with HTML5.</p>\n</footer>' }
    ],
    content: [
      { label: '<figure>', code: '<figure>\n  <img src="https://picsum.photos/400/250" alt="Sample photo" loading="lazy">\n  <figcaption>Figure 1: Illustration</figcaption>\n</figure>' },
      { label: '<blockquote>', code: '<blockquote cite="https://example.com">\n  <p>"Quoted insight"</p>\n  <cite>— Author</cite>\n</blockquote>' },
      { label: '<ul> & <li>', code: '<ul>\n  <li>First item</li>\n  <li>Second item</li>\n</ul>' },
      { label: '<table>', code: '<table>\n  <thead>\n    <tr><th>Header 1</th><th>Header 2</th></tr>\n  </thead>\n  <tbody>\n    <tr><td>Value A</td><td>Value B</td></tr>\n  </tbody>\n</table>' }
    ],
    form: [
      { label: '<form>', code: '<form action="#" method="POST">\n  <label for="name">Full Name</label>\n  <input type="text" id="name" name="name" required>\n  <button type="submit">Submit</button>\n</form>' },
      { label: '<input>', code: '<input type="email" id="email" name="email" placeholder="you@domain.com" required>' },
      { label: '<datalist>', code: '<input list="browsers" id="browser" name="browser">\n<datalist id="browsers">\n  <option value="Chrome">\n  <option value="Firefox">\n</datalist>' },
      { label: '<select>', code: '<select id="status" name="status">\n  <option value="draft">Draft</option>\n  <option value="published">Published</option>\n</select>' }
    ],
    interactive: [
      { label: '<dialog>', code: '<dialog id="noticeModal">\n  <h3>Modal Window</h3>\n  <p>Native HTML5 modal content.</p>\n  <button onclick="this.closest(\'dialog\').close()">Close</button>\n</dialog>' },
      { label: '<details>', code: '<details>\n  <summary>Click to expand</summary>\n  <p>Detailed collapsible information.</p>\n</details>' },
      { label: '<canvas>', code: '<canvas id="myCanvas" width="400" height="200" style="border: 1px solid #333;"></canvas>' }
    ]
  };

  return (
    <div className="flex flex-col h-full bg-neutral-900 border-r border-neutral-800">
      {/* Editor Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 border-b border-neutral-800 bg-neutral-900/90 text-xs">
        <div className="flex items-center gap-2 text-neutral-300">
          <FileCode className="w-3.5 h-3.5 text-blue-400" />
          <span className="font-medium">index.html</span>
          <span className="text-neutral-500">·</span>
          <span className="text-neutral-500 font-mono tabular-nums">{lineCount} lines</span>
          <span className="text-neutral-500">·</span>
          <span className="text-neutral-500 font-mono tabular-nums">{charCount} chars</span>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleFormat}
            title="Prettify & Indent HTML"
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors"
          >
            <Wand2 className="w-3 h-3 text-blue-400" />
            <span>Format</span>
          </button>

          <button
            onClick={handleMinify}
            title="Minify Markup"
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors"
          >
            <Minimize2 className="w-3 h-3 text-purple-400" />
            <span>Minify</span>
          </button>

          <button
            onClick={handleCopy}
            title="Copy Code"
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 text-neutral-400" />
                <span>Copy</span>
              </>
            )}
          </button>

          <button
            onClick={() => onChange('<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Document</title>\n</head>\n<body>\n  \n</body>\n</html>')}
            title="Reset to minimal boilerplate"
            className="flex items-center gap-1 px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-400 hover:text-neutral-200 transition-colors"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Quick Tag Insertion Ribbon */}
      <div className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-950/70 border-b border-neutral-800/80 text-xs overflow-x-auto no-scrollbar">
        <span className="text-neutral-500 font-medium shrink-0 mr-1 flex items-center gap-1">
          <Plus className="w-3 h-3" />
          <span>Insert:</span>
        </span>

        {/* Category Pills */}
        <div className="flex items-center gap-1 bg-neutral-900 rounded p-0.5 border border-neutral-800 shrink-0 mr-2">
          <button
            onClick={() => setActiveSnippetCategory('layout')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
              activeSnippetCategory === 'layout' ? 'bg-neutral-800 text-blue-400' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Layout
          </button>
          <button
            onClick={() => setActiveSnippetCategory('content')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
              activeSnippetCategory === 'content' ? 'bg-neutral-800 text-blue-400' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Content
          </button>
          <button
            onClick={() => setActiveSnippetCategory('form')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
              activeSnippetCategory === 'form' ? 'bg-neutral-800 text-blue-400' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Forms
          </button>
          <button
            onClick={() => setActiveSnippetCategory('interactive')}
            className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
              activeSnippetCategory === 'interactive' ? 'bg-neutral-800 text-blue-400' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Widgets
          </button>
        </div>

        {/* Snippet Badges */}
        <div className="flex items-center gap-1.5 shrink-0">
          {quickSnippets[activeSnippetCategory].map((s) => (
            <button
              key={s.label}
              onClick={() => insertSnippet(s.code)}
              className="px-2 py-0.5 rounded bg-neutral-900 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-neutral-800/80 font-mono text-[11px] transition-colors whitespace-nowrap"
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Code Textarea & Line Numbers */}
      <div className="relative flex-1 flex overflow-hidden bg-neutral-950 font-mono text-xs">
        {/* Line Numbers Gutter */}
        <div 
          aria-hidden="true" 
          className="w-12 select-none py-3 pr-2.5 text-right font-mono text-neutral-600 bg-neutral-950/80 border-r border-neutral-900/80 overflow-hidden leading-5 tabular-nums"
        >
          {lines.map((_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>

        {/* Code Input */}
        <textarea
          ref={textareaRef}
          value={code}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          spellCheck={false}
          autoCapitalize="off"
          autoComplete="off"
          autoCorrect="off"
          className="flex-1 resize-none bg-transparent py-3 px-3.5 text-neutral-200 font-mono text-xs leading-5 outline-none overflow-y-auto selection:bg-blue-600/30"
          placeholder="Type or paste HTML here..."
        />
      </div>

      {/* Editor Status Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 border-t border-neutral-800 bg-neutral-950 text-[11px] text-neutral-500 font-mono">
        <div className="flex items-center gap-3">
          <span>UTF-8</span>
          <span>·</span>
          <span>HTML5 Standard</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="tabular-nums">{(byteCount / 1024).toFixed(1)} KB</span>
          <span>·</span>
          <span>Tab: 2 spaces</span>
        </div>
      </div>
    </div>
  );
};
