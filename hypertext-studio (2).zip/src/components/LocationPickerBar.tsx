import React from 'react';
import { 
  Navigation, 
  MapPin, 
  Sliders, 
  Search,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { POPULAR_CITIES } from '../data/mockPosts';

interface LocationPickerBarProps {
  currentLat: number | null;
  currentLng: number | null;
  radiusKm: number;
  setRadiusKm?: (r: number) => void;
  onDetectGps: () => void;
  onSelectCity: (lat: number, lng: number) => void;
  gpsStatus: string;
  isDetecting: boolean;
  totalFound: number;
}

export const LocationPickerBar: React.FC<LocationPickerBarProps> = ({
  currentLat,
  currentLng,
  radiusKm,
  setRadiusKm,
  onDetectGps,
  onSelectCity,
  gpsStatus,
  isDetecting,
  totalFound,
}) => {
  return (
    <div className="bg-neutral-900 border-b border-neutral-800 p-4">
      <div className="max-w-5xl mx-auto space-y-3.5">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          {/* GPS Detector button */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onDetectGps}
              disabled={isDetecting}
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-sm transition-all disabled:opacity-50"
            >
              <Navigation className={`w-3.5 h-3.5 ${isDetecting ? 'animate-spin' : ''}`} />
              <span>{isDetecting ? 'जीपीएस खोजा जा रहा है...' : 'लाइव लोकेशन लें (GPS)'}</span>
            </button>

            {gpsStatus && (
              <span className="text-xs text-neutral-400 bg-neutral-950 px-3 py-1.5 rounded-lg border border-neutral-800 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>{gpsStatus}</span>
              </span>
            )}
          </div>

          {/* Fixed 5 KM Radius Badge */}
          <div className="flex items-center gap-1.5 bg-neutral-950 px-3 py-1.5 rounded-lg border border-neutral-800 self-start md:self-auto text-xs">
            <span className="text-neutral-400 font-medium">दायरा:</span>
            <span className="font-semibold text-orange-400 font-mono">5 KM</span>
            <span className="text-[10px] text-neutral-400 bg-neutral-900 px-1.5 py-0.5 rounded border border-neutral-800 font-sans">
              डिफ़ॉल्ट
            </span>
          </div>
        </div>

        {/* Quick City Presets */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1 text-xs text-neutral-400">
          <span className="shrink-0 flex items-center gap-1 font-medium text-neutral-500">
            <MapPin className="w-3 h-3 text-neutral-500" />
            <span>परीक्षण शहर:</span>
          </span>
          {POPULAR_CITIES.map((city) => (
            <button
              key={city.name}
              onClick={() => onSelectCity(city.lat, city.lng)}
              className="px-2.5 py-1 rounded-md bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/80 text-neutral-300 hover:text-white transition-colors shrink-0 whitespace-nowrap"
            >
              {city.name}
            </button>
          ))}

          <span className="ml-auto text-neutral-500 shrink-0 font-mono text-[11px] tabular-nums">
            {totalFound} पोस्ट उपलब्ध
          </span>
        </div>
      </div>
    </div>
  );
};
