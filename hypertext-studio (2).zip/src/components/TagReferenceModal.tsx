import React, { useState } from 'react';
import { 
  Search, 
  ExternalLink, 
  Plus, 
  Copy, 
  Check, 
  BookOpen, 
  Info, 
  ShieldCheck 
} from 'lucide-react';
import { HTML_TAGS } from '../data/htmlTags';
import { HtmlTagInfo, TagCategory } from '../types/htmlStudio';

interface TagReferenceModalProps {
  onInsertTag: (snippet: string) => void;
}

export const TagReferenceModal: React.FC<TagReferenceModalProps> = ({ onInsertTag }) => {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedTag, setSelectedTag] = useState<HtmlTagInfo>(HTML_TAGS[0]);
  const [copied, setCopied] = useState(false);

  const categories: string[] = [
    'All',
    'Document Metadata',
    'Sectioning',
    'Content Grouping',
    'Text Semantics',
    'Embedded & Media',
    'Tabular Data',
    'Forms & Controls',
    'Interactive Elements',
    'Web Components',
  ];

  const filteredTags = HTML_TAGS.filter((t) => {
    const matchesCategory = selectedCategory === 'All' || t.category === selectedCategory;
    const matchesSearch =
      t.tag.toLowerCase().includes(search.toLowerCase()) ||
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.description.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleCopySnippet = (snippet: string) => {
    navigator.clipboard.writeText(snippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  return (
    <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden bg-neutral-950">
      {/* Left List & Search Sidebar */}
      <div className="w-full md:w-80 lg:w-96 flex flex-col border-r border-neutral-800 bg-neutral-900/60 shrink-0">
        <div className="p-3 border-b border-neutral-800 space-y-2">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 text-neutral-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search HTML tags (e.g. dialog, table, img)..."
              className="w-full pl-9 pr-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded-md text-xs text-neutral-200 outline-none focus:border-blue-500"
            />
          </div>

          {/* Category Filter Horizontal Scroll */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2 py-1 rounded text-[11px] font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white'
                    : 'bg-neutral-800 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Tag List */}
        <div className="flex-1 overflow-y-auto divide-y divide-neutral-800/60">
          {filteredTags.length === 0 ? (
            <div className="p-6 text-center text-xs text-neutral-500">
              No HTML tags found matching "{search}".
            </div>
          ) : (
            filteredTags.map((t) => (
              <button
                key={t.tag}
                onClick={() => setSelectedTag(t)}
                className={`w-full text-left p-3 transition-colors flex items-center justify-between ${
                  selectedTag.tag === t.tag
                    ? 'bg-blue-600/10 border-l-2 border-blue-500 text-neutral-100'
                    : 'hover:bg-neutral-800/50 text-neutral-300'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-semibold text-blue-400">
                      &lt;{t.tag}&gt;
                    </span>
                    <span className="text-xs font-medium text-neutral-200">
                      {t.name}
                    </span>
                  </div>
                  <div className="text-[11px] text-neutral-500 truncate mt-0.5 max-w-[220px]">
                    {t.description}
                  </div>
                </div>

                <span className="text-[10px] text-neutral-500 bg-neutral-950 px-1.5 py-0.5 rounded border border-neutral-800 font-mono">
                  {t.selfClosing ? 'Void' : 'Paired'}
                </span>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Right Detail Pane */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-neutral-950">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Header */}
          <div className="border-b border-neutral-800 pb-4">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
              <div className="flex items-center gap-3">
                <h2 className="text-2xl font-bold font-mono text-blue-400">
                  &lt;{selectedTag.tag}&gt;
                </h2>
                <span className="text-xs px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 border border-neutral-700">
                  {selectedTag.category}
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-neutral-900 text-neutral-400 border border-neutral-800 font-mono">
                  {selectedTag.selfClosing ? 'Self-Closing Void' : 'Paired Opening & Closing'}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onInsertTag(selectedTag.snippet)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium transition-colors shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Insert to Editor</span>
                </button>

                <a
                  href={`https://developer.mozilla.org/en-US/docs/Web/HTML/Element/${selectedTag.mdnSlug}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-xs transition-colors border border-neutral-700"
                >
                  <span>MDN Docs</span>
                  <ExternalLink className="w-3 h-3 text-neutral-400" />
                </a>
              </div>
            </div>

            <h3 className="text-base font-semibold text-neutral-200">
              {selectedTag.name}
            </h3>
            <p className="text-sm text-neutral-400 mt-1 leading-relaxed">
              {selectedTag.description}
            </p>
          </div>

          {/* Accessibility & Spec notes */}
          {selectedTag.a11yNote && (
            <div className="flex items-start gap-3 p-3.5 rounded-lg bg-emerald-950/30 border border-emerald-800/40 text-emerald-300 text-xs">
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              <div>
                <strong className="block font-semibold mb-0.5">Accessibility (a11y) Guideline:</strong>
                <p className="text-emerald-200/90 leading-relaxed">{selectedTag.a11yNote}</p>
              </div>
            </div>
          )}

          {/* Common Attributes */}
          <div>
            <h4 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-400" />
              <span>Standard &amp; Common Attributes</span>
            </h4>
            {selectedTag.commonAttributes.length === 0 ? (
              <p className="text-xs text-neutral-500 italic">
                Accepts global HTML attributes (<code>id</code>, <code>class</code>, <code>style</code>, <code>data-*</code>, <code>role</code>, <code>aria-*</code>).
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {selectedTag.commonAttributes.map((attr) => (
                  <span
                    key={attr}
                    className="font-mono text-xs px-2 py-1 rounded bg-neutral-900 border border-neutral-800 text-neutral-300"
                  >
                    {attr}
                  </span>
                ))}
                <span className="font-mono text-xs px-2 py-1 text-neutral-500 italic">
                  + global attributes
                </span>
              </div>
            )}
          </div>

          {/* Example Code Snippet */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider">
                Example Usage Snippet
              </h4>
              <button
                onClick={() => handleCopySnippet(selectedTag.snippet)}
                className="flex items-center gap-1 text-xs text-neutral-400 hover:text-neutral-200"
              >
                {copied ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            <pre className="p-3.5 rounded-lg bg-neutral-900 border border-neutral-800 font-mono text-xs text-neutral-200 overflow-x-auto leading-relaxed">
              <code>{selectedTag.snippet}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
