import React, { useState } from 'react';
import { 
  X, 
  Code, 
  Copy, 
  Check, 
  Download,
  AlertCircle
} from 'lucide-react';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from '../services/supabase';

interface HtmlSourceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HtmlSourceModal: React.FC<HtmlSourceModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  // The corrected, production-ready standalone single-file HTML code
  const fixedStandaloneHtml = `<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>लोकल साथी - 5KM लोकल ऐप</title>
    <!-- सही Supabase v2 JS CDN लाइब्रेरी -->
    <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
    <style>
        :root {
            --primary: #ea580c;
            --primary-hover: #c2410c;
            --bg: #0c0a09;
            --card: #1c1917;
            --border: #292524;
            --text: #f5f5f4;
            --muted: #a8a29e;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans Devanagari", sans-serif;
            background-color: var(--bg);
            color: var(--text);
            padding: 20px 12px;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.5;
        }
        header { text-align: center; margin-bottom: 24px; }
        h1 { font-size: 1.6rem; color: #fff; margin-bottom: 6px; }
        p.subtitle { color: var(--muted); font-size: 0.9rem; }
        .controls { display: flex; flex-direction: column; gap: 10px; margin-bottom: 20px; }
        .load-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(234, 88, 12, 0.3);
            transition: background 0.2s;
        }
        .load-btn:hover { background: var(--primary-hover); }
        #status-msg { font-size: 0.85rem; color: #fb923c; text-align: center; min-height: 20px; }
        .post-card {
            background: var(--card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 16px;
            text-align: left;
        }
        .post-card h3 { font-size: 1.15rem; color: #fff; margin-bottom: 6px; }
        .post-card p { font-size: 0.9rem; color: #d6d3d1; margin-bottom: 12px; }
        .media { width: 100%; border-radius: 8px; margin-bottom: 12px; display: block; max-height: 360px; object-fit: cover; }
        .btn-delete {
            background: #ef4444;
            color: white;
            border: none;
            padding: 7px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
        }
        .btn-delete:hover { background: #dc2626; }
        .meta-tag { font-size: 11px; background: rgba(234, 88, 12, 0.15); color: #fb923c; padding: 2px 8px; border-radius: 4px; display: inline-block; margin-bottom: 8px; }
    </style>
</head>
<body>

    <header>
        <h1>📍 लोकल साथी (5KM दायरा)</h1>
        <p class="subtitle">अपने 5 किलोमीटर के दायरे में मौजूद फ़ोटो और वीडियो देखने के लिए नीचे बटन दबाएँ।</p>
    </header>

    <div class="controls">
        <button class="load-btn" onclick="getUserLocation()">📍 आस-पास के पोस्ट लोड करें</button>
        <div id="status-msg"></div>
    </div>
    
    <div id="posts-container"></div>

    <script>
        // Supabase कॉन्फ़िगरेशन
        const SUPABASE_URL = "${SUPABASE_URL}"; 
        const SUPABASE_ANON_KEY = "${SUPABASE_ANON_KEY}";
        
        // फिक्स: window.supabase से क्लाइंट बनाएं (वेरिएबल शैडोइंग एरर ठीक किया गया)
        const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

        // 1. यूज़र की GPS लोकेशन प्राप्त करना
        function getUserLocation() {
            const status = document.getElementById('status-msg');
            if (navigator.geolocation) {
                status.innerText = "GPS लोकेशन खोजी जा रही है...";
                navigator.geolocation.getCurrentPosition(fetchNearbyPosts, (err) => {
                    status.innerText = "";
                    alert("लोकेशन परमिशन एरर: " + err.message);
                });
            } else {
                status.innerText = "";
                alert("आपके ब्राउज़र में GPS सपोर्ट नहीं है।");
            }
        }

        // 2. Supabase RPC 'get_nearby_posts' से पोस्ट्स फेच करना
        async function fetchNearbyPosts(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const container = document.getElementById('posts-container');
            const status = document.getElementById('status-msg');
            
            status.innerText = "लोकेशन: " + lat.toFixed(4) + ", " + lng.toFixed(4);
            container.innerHTML = "<p style='text-align:center; color:#a8a29e;'>5 किमी के दायरे में पोस्ट खोज रहे हैं...</p>";

            const { data: posts, error } = await supabaseClient.rpc('get_nearby_posts', {
                user_lat: lat,
                user_lng: lng,
                radius_meters: 5000 // 5 किलोमीटर
            });

            if (error) {
                container.innerHTML = "<p style='color:#ef4444; text-align:center;'>डेटाबेस एरर: " + error.message + "<br><small>कृपया SQL सेटअप चलाएं।</small></p>";
                return;
            }

            if (!posts || posts.length === 0) {
                container.innerHTML = "<p style='text-align:center; color:#a8a29e;'>आपके 5 किमी के दायरे में अभी कोई पोस्ट नहीं मिला।</p>";
                return;
            }

            container.innerHTML = "";
            posts.forEach(post => {
                const postEl = document.createElement('div');
                postEl.className = 'post-card';
                
                let mediaTag = '';
                if (post.media_url) {
                    let mediaUrl = post.media_url;
                    if (!mediaUrl.startsWith('http')) {
                        const { data } = supabaseClient.storage.from('posts-media').getPublicUrl(post.media_url);
                        mediaUrl = data.publicUrl;
                    }
                    if (mediaUrl.endsWith('.mp4') || mediaUrl.endsWith('.mov') || mediaUrl.endsWith('.webm')) {
                        mediaTag = '<video src="' + mediaUrl + '" controls class="media"></video>';
                    } else {
                        mediaTag = '<img src="' + mediaUrl + '" class="media" alt="Post Media" onerror="this.style.display=\\'none\\'"/>';
                    }
                }

                postEl.innerHTML = 
                    '<span class="meta-tag">' + (post.distance_meters ? (post.distance_meters/1000).toFixed(1) + ' KM दूर' : 'लोकल') + '</span>' +
                    '<h3>' + (post.title || 'लोकल पोस्ट') + '</h3>' +
                    '<p>' + (post.description || '') + '</p>' +
                    mediaTag +
                    '<button class="btn-delete" onclick="deletePost(\\'' + post.id + '\\', \\'' + (post.media_url || '') + '\\')">पोस्ट डिलीट करें</button>';
                
                container.appendChild(postEl);
            });
        }

        // 3. पोस्ट डिलीट करना
        async function deletePost(postId, mediaUrl) {
            if (!confirm("क्या आप सचमुच इस पोस्ट को डिलीट करना चाहते हैं?")) return;

            if (mediaUrl && !mediaUrl.startsWith('http')) {
                await supabaseClient.storage.from('posts-media').remove([mediaUrl]);
            }

            const { error: dbError } = await supabaseClient.from('posts').delete().eq('id', postId);

            if (dbError) {
                alert("डिलीट एरर: " + dbError.message);
            } else {
                alert("पोस्ट सफलतापूर्वक डिलीट हो गया!");
                getUserLocation();
            }
        }
    </script>
</body>
</html>`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fixedStandaloneHtml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([fixedStandaloneHtml], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'local-sathi-standalone.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-3xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-8 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
              <Code className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                सुधारा गया सिंगल-फ़ाइल HTML कोड
              </h2>
              <p className="text-xs text-neutral-400">
                सीधे ब्राउज़र में चलाने योग्य पूर्ण स्टैंडअलोन फ़ाइल।
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Improvements Notice */}
        <div className="px-6 py-3 bg-neutral-950/80 border-b border-neutral-800 text-xs text-neutral-300 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>फ़िक्स: CDN स्क्रिप्ट URL सही किया गया और Supabase वेरिएबल शैडोइंग बग ठीक किया गया।</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-white font-medium transition-colors text-xs"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>कॉपी हो गया!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-neutral-400" />
                  <span>HTML कोड कॉपी करें</span>
                </>
              )}
            </button>

            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition-colors text-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>डाउनलोड (.html)</span>
            </button>
          </div>
        </div>

        {/* Code Viewer */}
        <div className="p-6 overflow-y-auto flex-1 font-mono text-xs">
          <pre className="p-4 bg-neutral-950 rounded-xl text-neutral-300 overflow-x-auto leading-relaxed border border-neutral-800">
            <code>{fixedStandaloneHtml}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
