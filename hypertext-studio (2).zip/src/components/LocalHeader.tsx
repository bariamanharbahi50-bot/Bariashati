import React from 'react';
import { 
  MapPin, 
  PlusCircle, 
  Database, 
  Code, 
  Compass, 
  RotateCw,
  SlidersHorizontal,
  Sparkles
} from 'lucide-react';

interface LocalHeaderProps {
  currentLat: number | null;
  currentLng: number | null;
  radiusKm: number;
  onRefresh: () => void;
  onOpenCreateModal: () => void;
  onOpenSqlGuide: () => void;
  onOpenHtmlSource: () => void;
  onOpenLogoModal: () => void;
  isLoading: boolean;
  isDemoMode: boolean;
  setIsDemoMode: (val: boolean) => void;
}

export const LocalHeader: React.FC<LocalHeaderProps> = ({
  currentLat,
  currentLng,
  radiusKm,
  onRefresh,
  onOpenCreateModal,
  onOpenSqlGuide,
  onOpenHtmlSource,
  onOpenLogoModal,
  isLoading,
  isDemoMode,
  setIsDemoMode,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-neutral-900/95 backdrop-blur-md border-b border-neutral-800">
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark with new LS Logo */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenLogoModal}
            className="w-10 h-10 rounded-xl bg-white p-0.5 shadow-md shadow-black/20 flex items-center justify-center overflow-hidden hover:scale-105 transition-transform border border-neutral-700/60 cursor-pointer"
            title="लोगो विवरण देखें और डाउनलोड करें"
          >
            <img
              src="/src/assets/images/local_sathi_logo_1793600927219.jpg"
              alt="लोकल साथी 'LS' लोकेशन लोगो"
              className="w-full h-full object-contain"
            />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap">
                लोकल साथी
              </span>
              <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-orange-500/15 text-orange-400 border border-orange-500/30 font-medium">
                {radiusKm}KM दायरा
              </span>
            </div>
            <div className="text-[11px] text-neutral-400 flex items-center gap-1.5 font-mono">
              <Compass className="w-3 h-3 text-neutral-500" />
              {currentLat !== null && currentLng !== null ? (
                <span className="tabular-nums">
                  {currentLat.toFixed(4)}° N, {currentLng.toFixed(4)}° E
                </span>
              ) : (
                <span className="text-neutral-500">जीपीएस कनेक्ट नहीं है</span>
              )}
            </div>
          </div>
        </div>

        {/* Zone 2: Navigation & Mode Controls */}
        <div className="hidden sm:flex items-center gap-2 text-xs">
          {/* Demo Mode Toggle */}
          <button
            onClick={() => setIsDemoMode(!isDemoMode)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors flex items-center gap-1.5 ${
              isDemoMode
                ? 'bg-amber-500/15 text-amber-300 border-amber-500/40'
                : 'bg-neutral-800 text-neutral-300 border-neutral-700 hover:bg-neutral-700'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${isDemoMode ? 'bg-amber-400' : 'bg-neutral-500'}`} />
            <span>{isDemoMode ? 'डेमो मोड (सक्रिय)' : 'लाइव Supabase'}</span>
          </button>

          <button
            onClick={onOpenSqlGuide}
            className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700/80 transition-colors flex items-center gap-1.5"
            title="Supabase RPC और SQL सेटअप कोड देखें"
          >
            <Database className="w-3.5 h-3.5 text-blue-400" />
            <span>SQL गाइड</span>
          </button>

          <button
            onClick={onOpenHtmlSource}
            className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700/80 transition-colors flex items-center gap-1.5"
            title="सुधारा गया सिंगल-फ़ाइल HTML कोड डाउनलोड करें"
          >
            <Code className="w-3.5 h-3.5 text-emerald-400" />
            <span>HTML फ़ाइल</span>
          </button>

          <button
            onClick={onOpenLogoModal}
            className="px-2.5 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700/80 transition-colors flex items-center gap-1.5"
            title="नया 'LS' लोगो देखें व डाउनलोड करें"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>लोगो देखें</span>
          </button>
        </div>

        {/* Zone 3: Primary Action CTA */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="p-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors disabled:opacity-50"
            title="आस-पास के पोस्ट रीफ्रेश करें"
          >
            <RotateCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-orange-400' : ''}`} />
          </button>

          <button
            onClick={onOpenCreateModal}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-white text-xs font-semibold shadow-md shadow-orange-900/30 transition-all hover:scale-[1.02] active:scale-[0.98] whitespace-nowrap"
          >
            <PlusCircle className="w-4 h-4" />
            <span>नया पोस्ट डालें</span>
          </button>
        </div>
      </div>
    </header>
  );
};
