import React, { useState } from 'react';
import { 
  X, 
  Database, 
  Copy, 
  Check, 
  ExternalLink,
  ShieldAlert,
  Terminal
} from 'lucide-react';
import { SUPABASE_SQL_MIGRATION, SUPABASE_URL } from '../services/supabase';

interface SqlGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SqlGuideModal: React.FC<SqlGuideModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  const [copiedCategorySql, setCopiedCategorySql] = useState(false);

  const handleCopyCategorySql = () => {
    navigator.clipboard.writeText("ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'general';");
    setCopiedCategorySql(true);
    setTimeout(() => setCopiedCategorySql(false), 2000);
  };

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_MIGRATION);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-8 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30 flex items-center justify-center font-bold">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Supabase बैकएंड सेटअप गाइड
              </h2>
              <p className="text-xs text-neutral-400">
                अपने Supabase प्रोजेक्ट में 5KM जियो-क्वेरी (RPC) और टेबल एक्टिवेट करें।
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs">
          {/* Quick Category Fix Banner */}
          <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-600/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-amber-300 flex items-center gap-1.5">
                <span>⚡ 'category' कॉलम एरर का त्वरित समाधान (1-Click SQL):</span>
              </span>
              <button
                onClick={handleCopyCategorySql}
                className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs transition-colors"
              >
                {copiedCategorySql ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-white" />
                    <span>कॉपी हो गया!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>कमांड कॉपी करें</span>
                  </>
                )}
              </button>
            </div>
            <p className="text-neutral-300 text-[11px]">
              यदि डेटाबेस में <code>posts</code> टेबल पहले से बनी है, तो Supabase SQL Editor में केवल यह एक लाइन रन करें:
            </p>
            <pre className="p-2.5 bg-black/60 rounded-lg text-amber-200 font-mono text-[11px] overflow-x-auto border border-amber-900/60">
              <code>ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'general';</code>
            </pre>
          </div>

          {/* Quick Likes & Comments SQL Banner */}
          <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-600/40 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-rose-300 flex items-center gap-1.5">
                <span>❤️ 'likes' और 💬 'comments' टेबल्स निर्माण (1-Click SQL):</span>
              </span>
              <button
                onClick={() => {
                  const sql = `CREATE TABLE IF NOT EXISTS public.likes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_id UUID REFERENCES public.posts(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read likes" ON public.likes FOR SELECT USING (true);
CREATE POLICY "Public insert likes" ON public.likes FOR INSERT WITH CHECK (true);
CREATE POLICY "Public delete likes" ON public.likes FOR DELETE USING (true);

CREATE TABLE IF NOT EXISTS public.comments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_id UUID REFERENCES public.posts(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read comments" ON public.comments FOR SELECT USING (true);
CREATE POLICY "Public insert comments" ON public.comments FOR INSERT WITH CHECK (true);
CREATE POLICY "Public delete comments" ON public.comments FOR DELETE USING (true);`;
                  navigator.clipboard.writeText(sql);
                  alert('Likes & Comments SQL कॉपी हो गया!');
                }}
                className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs transition-colors"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>कमांड कॉपी करें</span>
              </button>
            </div>
            <p className="text-neutral-300 text-[11px]">
              लाइक (❤️) और कमेंट (💬) डेटा को Supabase में स्टोर करने के लिए यह SQL रन करें।
            </p>
          </div>

          {/* Step 1 */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-neutral-200">
                1. Supabase SQL Editor में यह स्क्रिप्ट चलाएँ:
              </span>
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs transition-colors"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-white" />
                    <span>कॉपी हो गया!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>SQL कॉपी करें</span>
                  </>
                )}
              </button>
            </div>

            <pre className="p-3 bg-neutral-900 rounded-lg text-neutral-300 font-mono text-[11px] overflow-x-auto leading-relaxed border border-neutral-800 max-h-56">
              <code>{SUPABASE_SQL_MIGRATION}</code>
            </pre>
          </div>

          {/* Step 2 */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
            <h4 className="font-semibold text-neutral-200">
              2. स्टोरेज बकेट (Storage Bucket):
            </h4>
            <p className="text-neutral-400 leading-relaxed">
              Supabase डैशबोर्ड में <strong>Storage</strong> मेनू में जाएँ, और <code className="text-orange-400">posts-media</code> नाम से एक नया <strong>Public Bucket</strong> बनाएँ ताकि फ़ोटो और वीडियो पब्लिकली देखे जा सकें।
            </p>
          </div>

          {/* Quick Link */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-neutral-800/60 border border-neutral-700/60">
            <div className="text-neutral-300">
              प्रोजेक्ट URL: <span className="font-mono text-neutral-400">{SUPABASE_URL}</span>
            </div>
            <a
              href="https://supabase.com/dashboard"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1 text-blue-400 hover:text-blue-300 font-medium"
            >
              <span>डैशबोर्ड खोलें</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-900 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-neutral-800 hover:bg-neutral-700"
          >
            समझ गया (बंद करें)
          </button>
        </div>
      </div>
    </div>
  );
};
