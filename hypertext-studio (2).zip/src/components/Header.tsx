import React from 'react';
import { 
  Code2, 
  BookOpen, 
  Layers, 
  ShieldCheck, 
  Hash, 
  Sparkles, 
  Download, 
  Share2 
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'editor' | 'reference' | 'tree' | 'audit' | 'entities';
  setActiveTab: (tab: 'editor' | 'reference' | 'tree' | 'audit' | 'entities') => void;
  onOpenTemplates: () => void;
  onExportHtml: () => void;
  issueCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenTemplates,
  onExportHtml,
  issueCount
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 border-b border-neutral-800 bg-neutral-900/90 backdrop-blur-md sticky top-0 z-40">
      {/* Zone 1: Brand Wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-sm">
          &lt;/&gt;
        </div>
        <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0">
          HyperText Studio
        </span>
      </div>

      {/* Zone 2: Navigation Links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-400">
        <button
          onClick={() => setActiveTab('editor')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'editor' ? 'text-blue-400' : 'hover:text-neutral-200'
          }`}
        >
          <Code2 className="w-4 h-4" />
          <span>Editor &amp; Canvas</span>
        </button>

        <button
          onClick={() => setActiveTab('reference')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'reference' ? 'text-blue-400' : 'hover:text-neutral-200'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>HTML5 Dictionary</span>
        </button>

        <button
          onClick={() => setActiveTab('tree')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'tree' ? 'text-blue-400' : 'hover:text-neutral-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>DOM Tree</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'audit' ? 'text-blue-400' : 'hover:text-neutral-200'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Accessibility &amp; SEO</span>
          {issueCount > 0 && (
            <span className="text-xs px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
              {issueCount}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('entities')}
          className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'entities' ? 'text-blue-400' : 'hover:text-neutral-200'
          }`}
        >
          <Hash className="w-4 h-4" />
          <span>Entities</span>
        </button>
      </nav>

      {/* Zone 3: Actions */}
      <div className="flex items-center gap-2.5 shrink-0">
        <button
          onClick={onOpenTemplates}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-200 bg-neutral-800 hover:bg-neutral-700 rounded-md transition-colors border border-neutral-700/80 whitespace-nowrap shrink-0"
        >
          <Sparkles className="w-3.5 h-3.5 text-blue-400" />
          <span>Templates</span>
        </button>

        <button
          onClick={onExportHtml}
          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors whitespace-nowrap shrink-0 shadow-sm"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export .html</span>
        </button>
      </div>
    </header>
  );
};
