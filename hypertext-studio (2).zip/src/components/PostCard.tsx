import React, { useState } from 'react';
import { 
  Trash2, 
  MapPin, 
  AlertTriangle, 
  Calendar, 
  ShoppingBag, 
  FileText
} from 'lucide-react';
import { LocalPost, supabase } from '../services/supabase';

interface PostCardProps {
  post: LocalPost;
  onDelete: (postId: string, mediaUrl?: string) => Promise<void>;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onDelete }) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  // 1. Bucket नाम सिर्फ 'posts-media' use करें
  // 2. Upload के बाद supabase.storage.from('posts-media').getPublicUrl(fileName).data.publicUrl से URL निकालें
  let mediaUrl = post.media_url || '';
  if (mediaUrl && !mediaUrl.startsWith('http') && !mediaUrl.startsWith('data:') && !mediaUrl.startsWith('blob:')) {
    const { data } = supabase.storage.from('posts-media').getPublicUrl(mediaUrl);
    if (data?.publicUrl) {
      mediaUrl = data.publicUrl;
    }
  }

  // 3. Feed में पोस्ट दिखाते वक़्त p.media_url चेक करें - अगर URL में .mp4 या video है तो <video controls>, वरना <img>
  const isVideo =
    mediaUrl.includes('.mp4') ||
    mediaUrl.includes('.mov') ||
    mediaUrl.includes('.webm') ||
    mediaUrl.includes('video');

  const formatDistance = (meters?: number) => {
    if (meters === undefined || meters === null) return null;
    if (meters < 1000) return `${Math.round(meters)} मीटर दूर`;
    return `${(meters / 1000).toFixed(2)} KM दूर`;
  };

  const getCategoryBadge = () => {
    switch (post.category) {
      case 'alert':
        return (
          <span className="flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-red-500/15 text-red-400 border border-red-500/30">
            <AlertTriangle className="w-3 h-3" />
            <span>अलर्ट</span>
          </span>
        );
      case 'event':
        return (
          <span className="flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-400 border border-blue-500/30">
            <Calendar className="w-3 h-3" />
            <span>कार्यक्रम</span>
          </span>
        );
      case 'market':
        return (
          <span className="flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <ShoppingBag className="w-3 h-3" />
            <span>लोकल मंडी</span>
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300 border border-neutral-700">
            <FileText className="w-3 h-3" />
            <span>सामान्य</span>
          </span>
        );
    }
  };

  const handleDeleteClick = async () => {
    try {
      setIsDeleting(true);
      await onDelete(post.id, post.media_url);
    } finally {
      setIsDeleting(false);
      setShowConfirm(false);
    }
  };

  return (
    <article className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden shadow-lg hover:border-neutral-700 transition-all flex flex-col">
      {/* 3. Media Display: Video controls or Image */}
      {mediaUrl ? (
        <div className="w-full bg-black overflow-hidden border-b border-neutral-800 flex items-center justify-center">
          {isVideo ? (
            <video
              src={mediaUrl}
              controls
              playsInline
              preload="metadata"
              onPlay={(e) => {
                const currentVideo = e.currentTarget;
                document.querySelectorAll('video').forEach((v) => {
                  if (v !== currentVideo) v.pause();
                });
              }}
              className="w-full h-72 object-cover bg-black"
            />
          ) : (
            <img
              src={mediaUrl}
              alt={post.title || "लोकल साथी पोस्ट"}
              className="w-full h-72 object-cover bg-neutral-950"
            />
          )}
        </div>
      ) : null}

      {/* Content */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          <div className="flex items-center justify-between gap-2 mb-2">
            {getCategoryBadge()}
            {post.distance_meters !== undefined && (
              <span className="text-xs font-mono font-medium text-orange-400 bg-orange-950/40 px-2 py-0.5 rounded border border-orange-800/40 tabular-nums">
                {formatDistance(post.distance_meters)}
              </span>
            )}
          </div>

          {/* 4. p.title को {post.title} की तरह दिखाएं, string की तरह नहीं */}
          <h3 className="text-base sm:text-lg font-bold text-neutral-100 leading-snug mb-1.5">
            {post.title}
          </h3>

          {post.description && (
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed line-clamp-3">
              {post.description}
            </p>
          )}
        </div>

        {/* Footer info & delete action */}
        <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between gap-2 text-xs text-neutral-400">
          <div className="flex items-center gap-1 font-mono text-[11px] text-neutral-500">
            <MapPin className="w-3 h-3 text-neutral-500" />
            <span className="tabular-nums">
              {post.latitude ? post.latitude.toFixed(3) : '0.000'}°, {post.longitude ? post.longitude.toFixed(3) : '0.000'}°
            </span>
          </div>

          {showConfirm ? (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setShowConfirm(false)}
                className="px-2 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px]"
              >
                रद्द करें
              </button>
              <button
                onClick={handleDeleteClick}
                disabled={isDeleting}
                className="px-2.5 py-1 rounded bg-red-600 hover:bg-red-500 text-white font-medium text-[11px] disabled:opacity-50"
              >
                {isDeleting ? 'हटा रहे हैं...' : 'हाँ, हटाएं'}
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowConfirm(true)}
              className="flex items-center gap-1 text-neutral-500 hover:text-red-400 p-1 rounded hover:bg-neutral-800 transition-colors"
              title="यह पोस्ट और मीडिया हटाएं"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="text-[11px]">डिलीट</span>
            </button>
          )}
        </div>
      </div>
    </article>
  );
};
