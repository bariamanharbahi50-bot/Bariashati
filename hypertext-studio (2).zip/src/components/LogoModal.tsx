import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Copy, 
  Check, 
  Sparkles, 
  Palette, 
  ExternalLink 
} from 'lucide-react';

interface LogoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LogoModal: React.FC<LogoModalProps> = ({ isOpen, onClose }) => {
  const [copiedColor, setCopiedColor] = useState<string | null>(null);

  if (!isOpen) return null;

  const logoImagePath = "/src/assets/images/local_sathi_logo_1793600927219.jpg";

  const colorPalette = [
    { name: 'गहरा नीला (Letter L & Pin)', hex: '#002B49', role: 'अक्षर L और लोकेशन पिन' },
    { name: 'चमकदार नारंगी (Letter S)', hex: '#FF5722', role: 'अक्षर S (जीवंत समुदाय)' },
    { name: 'स्वच्छ सफेद (Background)', hex: '#FFFFFF', role: 'साफ एवं मिनिमलिस्ट बैकग्राउंड' },
  ];

  const handleCopyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(hex);
    setTimeout(() => setCopiedColor(null), 1800);
  };

  const handleDownloadLogo = () => {
    const a = document.createElement('a');
    a.href = logoImagePath;
    a.download = 'local-sathi-minimalist-logo.jpg';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm overflow-y-auto">
      <div className="w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-8 flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-500/20 text-orange-400 border border-orange-500/30 flex items-center justify-center font-bold">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                लोकल साथी — ब्रांड लोगो (Logo Showcase)
              </h2>
              <p className="text-xs text-neutral-400">
                आधुनिक और मिनिमलिस्ट 'LS' लोकेशन पिन लोगो
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Logo Card with Clean White Background */}
          <div className="flex flex-col items-center justify-center p-8 bg-white rounded-2xl shadow-inner border border-neutral-200">
            <div className="w-56 h-56 sm:w-64 sm:h-64 rounded-xl overflow-hidden shadow-sm flex items-center justify-center">
              <img
                src={logoImagePath}
                alt="लोकल साथी 'LS' लोकेशन पिन मिनिमलिस्ट लोगो"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="text-center mt-3">
              <span className="text-xs font-semibold text-neutral-800 uppercase tracking-widest font-mono">
                LOCAL SAATHI · LS MONOGRAM
              </span>
            </div>
          </div>

          {/* Design Concept Details */}
          <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-2">
            <h4 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-orange-400" />
              <span>डिज़ाइन विशेषताएं (Design Highlights):</span>
            </h4>
            <ul className="text-xs text-neutral-400 space-y-1.5 leading-relaxed pl-1">
              <li>
                • <strong className="text-neutral-200">'L' और 'S' का कलात्मक जुड़ाव</strong>: Local (L) और Saathi (S) का मॉडर्न इंटरलॉकिंग मोनोग्राम।
              </li>
              <li>
                • <strong className="text-neutral-200">लोकेशन पिन (Map Pin)</strong>: 5KM हाइपरलोकल दायरे और स्थानीय उपस्थिति का सटीक प्रतीक।
              </li>
              <li>
                • <strong className="text-neutral-200">रंग संयोजन</strong>: गहरा नीला (विश्वसनीयता व स्थिरता) + चमकदार नारंगी (ऊर्जावान व सक्रिय समुदाय)।
              </li>
              <li>
                • <strong className="text-neutral-200">सफ़ेद बैकग्राउंड</strong>: स्वच्छ, आधुनिक और मिनिमलिस्ट कॉर्पोरेट विज़ुअल पहचान।
              </li>
            </ul>
          </div>

          {/* Color Palette Values */}
          <div>
            <h4 className="text-xs font-semibold text-neutral-400 mb-2">
              ब्रांड कलर पैलेट (क्लिक करके Hex कोड कॉपी करें):
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {colorPalette.map((col) => (
                <button
                  key={col.hex}
                  onClick={() => handleCopyHex(col.hex)}
                  className="p-3 rounded-xl bg-neutral-950 border border-neutral-800 hover:border-neutral-700 transition-colors flex items-center justify-between text-left group"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-6 h-6 rounded-md shadow-sm border border-neutral-700 shrink-0"
                      style={{ backgroundColor: col.hex }}
                    />
                    <div>
                      <div className="text-[11px] font-mono font-bold text-neutral-200">
                        {col.hex}
                      </div>
                      <div className="text-[10px] text-neutral-400 truncate max-w-[100px]">
                        {col.role}
                      </div>
                    </div>
                  </div>

                  {copiedColor === col.hex ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5 text-neutral-600 group-hover:text-neutral-300" />
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-neutral-800 bg-neutral-900/90 flex items-center justify-between gap-3">
          <span className="text-xs text-neutral-400">
            उच्च-रिज़ॉल्यूशन मूल लोगो
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2 rounded-lg text-xs font-medium text-neutral-400 hover:text-white bg-neutral-800 hover:bg-neutral-700 transition-colors"
            >
              बंद करें
            </button>

            <button
              onClick={handleDownloadLogo}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 shadow-md shadow-orange-950/40 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>लोगो डाउनलोड करें (HD)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
