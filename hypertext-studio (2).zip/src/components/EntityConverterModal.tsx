import React, { useState } from 'react';
import { 
  Hash, 
  Copy, 
  Check, 
  ArrowRightLeft, 
  Search 
} from 'lucide-react';
import { encodeHtmlEntities, decodeHtmlEntities } from '../utils/htmlFormatter';

interface EntityItem {
  char: string;
  name: string;
  namedEntity: string;
  decimalEntity: string;
  category: 'Typography' | 'Math & Logic' | 'Currency' | 'Arrows' | 'Symbols';
}

const COMMON_ENTITIES: EntityItem[] = [
  // Typography
  { char: '&', name: 'Ampersand', namedEntity: '&amp;', decimalEntity: '&#38;', category: 'Typography' },
  { char: '<', name: 'Less Than', namedEntity: '&lt;', decimalEntity: '&#60;', category: 'Typography' },
  { char: '>', name: 'Greater Than', namedEntity: '&gt;', decimalEntity: '&#62;', category: 'Typography' },
  { char: '"', name: 'Double Quote', namedEntity: '&quot;', decimalEntity: '&#34;', category: 'Typography' },
  { char: "'", name: 'Apostrophe', namedEntity: '&apos;', decimalEntity: '&#39;', category: 'Typography' },
  { char: ' ', name: 'Non-breaking Space', namedEntity: '&nbsp;', decimalEntity: '&#160;', category: 'Typography' },
  { char: '—', name: 'Em Dash', namedEntity: '&mdash;', decimalEntity: '&#8212;', category: 'Typography' },
  { char: '–', name: 'En Dash', namedEntity: '&ndash;', decimalEntity: '&#8211;', category: 'Typography' },
  { char: '…', name: 'Horizontal Ellipsis', namedEntity: '&hellip;', decimalEntity: '&#8230;', category: 'Typography' },
  { char: '•', name: 'Bullet Point', namedEntity: '&bull;', decimalEntity: '&#8226;', category: 'Typography' },

  // Currency
  { char: '©', name: 'Copyright Sign', namedEntity: '&copy;', decimalEntity: '&#169;', category: 'Currency' },
  { char: '®', name: 'Registered Trademark', namedEntity: '&reg;', decimalEntity: '&#174;', category: 'Currency' },
  { char: '™', name: 'Trade Mark', namedEntity: '&trade;', decimalEntity: '&#8482;', category: 'Currency' },
  { char: '€', name: 'Euro Sign', namedEntity: '&euro;', decimalEntity: '&#8364;', category: 'Currency' },
  { char: '£', name: 'Pound Sign', namedEntity: '&pound;', decimalEntity: '&#163;', category: 'Currency' },
  { char: '¥', name: 'Yen Sign', namedEntity: '&yen;', decimalEntity: '&#165;', category: 'Currency' },
  { char: '¢', name: 'Cent Sign', namedEntity: '&cent;', decimalEntity: '&#162;', category: 'Currency' },

  // Arrows
  { char: '←', name: 'Left Arrow', namedEntity: '&larr;', decimalEntity: '&#8592;', category: 'Arrows' },
  { char: '→', name: 'Right Arrow', namedEntity: '&rarr;', decimalEntity: '&#8594;', category: 'Arrows' },
  { char: '↑', name: 'Up Arrow', namedEntity: '&uarr;', decimalEntity: '&#8593;', category: 'Arrows' },
  { char: '↓', name: 'Down Arrow', namedEntity: '&darr;', decimalEntity: '&#8595;', category: 'Arrows' },
  { char: '⇄', name: 'Left Right Arrows', namedEntity: '&harr;', decimalEntity: '&#8644;', category: 'Arrows' },

  // Math & Logic
  { char: '×', name: 'Multiplication Sign', namedEntity: '&times;', decimalEntity: '&#215;', category: 'Math & Logic' },
  { char: '÷', name: 'Division Sign', namedEntity: '&divide;', decimalEntity: '&#247;', category: 'Math & Logic' },
  { char: '±', name: 'Plus-Minus Sign', namedEntity: '&plusmn;', decimalEntity: '&#177;', category: 'Math & Logic' },
  { char: '≠', name: 'Not Equal', namedEntity: '&ne;', decimalEntity: '&#8800;', category: 'Math & Logic' },
  { char: '≤', name: 'Less-Than or Equal', namedEntity: '&le;', decimalEntity: '&#8804;', category: 'Math & Logic' },
  { char: '≥', name: 'Greater-Than or Equal', namedEntity: '&ge;', decimalEntity: '&#8805;', category: 'Math & Logic' },
  { char: '∞', name: 'Infinity', namedEntity: '&infin;', decimalEntity: '&#8734;', category: 'Math & Logic' },

  // Symbols
  { char: '♥', name: 'Black Heart Suit', namedEntity: '&hearts;', decimalEntity: '&#9829;', category: 'Symbols' },
  { char: '★', name: 'Black Star', namedEntity: '&#9733;', decimalEntity: '&#9733;', category: 'Symbols' },
  { char: '✓', name: 'Check Mark', namedEntity: '&#10003;', decimalEntity: '&#10003;', category: 'Symbols' },
  { char: '✗', name: 'Cross Mark', namedEntity: '&#10007;', decimalEntity: '&#10007;', category: 'Symbols' },
];

export const EntityConverterModal: React.FC = () => {
  const [search, setSearch] = useState('');
  const [inputText, setInputText] = useState('HTML & CSS > JS: "Fast & Reliable"');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const encoded = encodeHtmlEntities(inputText);

  const filteredEntities = COMMON_ENTITIES.filter((item) => {
    return (
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.namedEntity.toLowerCase().includes(search.toLowerCase()) ||
      item.char.includes(search) ||
      item.category.toLowerCase().includes(search.toLowerCase())
    );
  });

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-neutral-950 p-4 sm:p-6">
      <div className="max-w-4xl mx-auto w-full space-y-6">
        {/* Encoder / Decoder Live Tester */}
        <div className="p-5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-4">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-blue-400" />
            <h2 className="text-base font-bold text-neutral-100">
              Interactive Entity Encoder / Escaper
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1.5">
                Plain Text with Special Characters
              </label>
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                rows={3}
                className="w-full p-2.5 bg-neutral-950 border border-neutral-800 rounded-lg text-xs font-mono text-neutral-200 outline-none focus:border-blue-500"
                placeholder="Type symbols like < > & '..."
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-medium text-neutral-400">
                  Escaped HTML Entity Output
                </label>
                <button
                  onClick={() => handleCopy('output', encoded)}
                  className="flex items-center gap-1 text-[11px] text-blue-400 hover:text-blue-300"
                >
                  {copiedId === 'output' ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
              <textarea
                readOnly
                value={encoded}
                rows={3}
                className="w-full p-2.5 bg-neutral-950/70 border border-neutral-800 rounded-lg text-xs font-mono text-neutral-300 outline-none select-all"
              />
            </div>
          </div>
        </div>

        {/* Entities Cheatsheet Dictionary */}
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-neutral-200">
                HTML Character Entities Reference
              </h3>
              <p className="text-xs text-neutral-500">
                Click any entity to copy its code directly.
              </p>
            </div>

            <div className="relative w-64">
              <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search entities (e.g. copy, arrow)..."
                className="w-full pl-8 pr-2.5 py-1 bg-neutral-900 border border-neutral-800 rounded text-xs text-neutral-200 outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {filteredEntities.map((ent) => (
              <div
                key={ent.name}
                onClick={() => handleCopy(ent.name, ent.namedEntity)}
                className="p-3 rounded-lg bg-neutral-900/60 hover:bg-neutral-900 border border-neutral-800 flex items-center justify-between cursor-pointer transition-colors group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded bg-neutral-950 border border-neutral-800 flex items-center justify-center text-lg text-blue-400 font-serif">
                    {ent.char}
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-neutral-200">
                      {ent.name}
                    </div>
                    <div className="font-mono text-[11px] text-neutral-400">
                      {ent.namedEntity}
                    </div>
                  </div>
                </div>

                <div className="text-neutral-500 group-hover:text-neutral-300 transition-colors">
                  {copiedId === ent.name ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
