import React, { useEffect, useRef, useState } from 'react';
import { 
  Laptop, 
  Tablet, 
  Smartphone, 
  Maximize2, 
  RotateCw, 
  Terminal, 
  Trash2, 
  AlertCircle,
  ExternalLink
} from 'lucide-react';
import { ConsoleLogMessage, ViewportMode } from '../types/htmlStudio';

interface LivePreviewProps {
  html: string;
}

export const LivePreview: React.FC<LivePreviewProps> = ({ html }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [viewport, setViewport] = useState<ViewportMode>('responsive');
  const [showConsole, setShowConsole] = useState(false);
  const [logs, setLogs] = useState<ConsoleLogMessage[]>([]);
  const [key, setKey] = useState(0);

  // Script to intercept iframe console logs and window errors
  const consoleInterceptor = `
    <script>
      (function() {
        const _log = console.log;
        const _info = console.info;
        const _warn = console.warn;
        const _error = console.error;

        function emit(type, args) {
          try {
            const content = Array.from(args).map(a => {
              if (typeof a === 'object') {
                try { return JSON.stringify(a, null, 2); } catch(e) { return String(a); }
              }
              return String(a);
            }).join(' ');
            window.parent.postMessage({ type: 'CONSOLE_LOG', level: type, content: content }, '*');
          } catch(e) {}
        }

        console.log = function(...args) { _log.apply(console, args); emit('log', args); };
        console.info = function(...args) { _info.apply(console, args); emit('info', args); };
        console.warn = function(...args) { _warn.apply(console, args); emit('warn', args); };
        console.error = function(...args) { _error.apply(console, args); emit('error', args); };

        window.addEventListener('error', function(e) {
          emit('error', [e.message + ' (line ' + e.lineno + ')']);
        });
      })();
    </script>
  `;

  // Inject console interceptor right before </head> or <body>
  let finalHtml = html;
  if (finalHtml.includes('</head>')) {
    finalHtml = finalHtml.replace('</head>', `${consoleInterceptor}</head>`);
  } else if (finalHtml.includes('<body>')) {
    finalHtml = finalHtml.replace('<body>', `<body>${consoleInterceptor}`);
  } else {
    finalHtml = `${consoleInterceptor}${finalHtml}`;
  }

  // Listen for console messages from iframe
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data && e.data.type === 'CONSOLE_LOG') {
        const newMsg: ConsoleLogMessage = {
          id: `${Date.now()}-${Math.random()}`,
          type: e.data.level,
          content: e.data.content,
          timestamp: new Date().toLocaleTimeString(),
        };
        setLogs((prev) => [...prev.slice(-99), newMsg]);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleRefresh = () => {
    setKey((prev) => prev + 1);
  };

  const handleClearLogs = () => {
    setLogs([]);
  };

  const getViewportWidth = () => {
    switch (viewport) {
      case 'desktop':
        return 'w-[1024px] max-w-full';
      case 'tablet':
        return 'w-[768px] max-w-full';
      case 'mobile':
        return 'w-[375px] max-w-full';
      case 'responsive':
      default:
        return 'w-full';
    }
  };

  const errorCount = logs.filter((l) => l.type === 'error').length;
  const warnCount = logs.filter((l) => l.type === 'warn').length;

  return (
    <div className="flex flex-col h-full bg-neutral-950 overflow-hidden">
      {/* Preview Header / Device Toolbar */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-neutral-800 bg-neutral-900/90 text-xs">
        {/* Device Switcher */}
        <div className="flex items-center gap-1 bg-neutral-950 p-0.5 rounded-lg border border-neutral-800">
          <button
            onClick={() => setViewport('responsive')}
            title="Responsive (Fluid 100%)"
            className={`px-2 py-1 rounded text-xs flex items-center gap-1 transition-colors ${
              viewport === 'responsive' ? 'bg-neutral-800 text-blue-400 font-medium' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Fluid</span>
          </button>

          <button
            onClick={() => setViewport('desktop')}
            title="Desktop View (1024px)"
            className={`px-2 py-1 rounded text-xs flex items-center gap-1 transition-colors ${
              viewport === 'desktop' ? 'bg-neutral-800 text-blue-400 font-medium' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Desktop</span>
          </button>

          <button
            onClick={() => setViewport('tablet')}
            title="Tablet View (768px)"
            className={`px-2 py-1 rounded text-xs flex items-center gap-1 transition-colors ${
              viewport === 'tablet' ? 'bg-neutral-800 text-blue-400 font-medium' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Tablet</span>
          </button>

          <button
            onClick={() => setViewport('mobile')}
            title="Mobile View (375px)"
            className={`px-2 py-1 rounded text-xs flex items-center gap-1 transition-colors ${
              viewport === 'mobile' ? 'bg-neutral-800 text-blue-400 font-medium' : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Mobile</span>
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleRefresh}
            title="Reload Sandbox Frame"
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors"
          >
            <RotateCw className="w-3 h-3 text-neutral-400" />
            <span className="hidden sm:inline">Reload</span>
          </button>

          <button
            onClick={() => setShowConsole(!showConsole)}
            title="Toggle Console Output"
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors ${
              showConsole ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30' : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
            }`}
          >
            <Terminal className="w-3 h-3" />
            <span>Console</span>
            {(errorCount > 0 || warnCount > 0) && (
              <span className={`text-[10px] px-1 rounded font-mono ${errorCount > 0 ? 'bg-red-500/20 text-red-400' : 'bg-amber-500/20 text-amber-400'}`}>
                {errorCount > 0 ? errorCount : warnCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Main Sandbox Frame Container */}
      <div className="flex-1 bg-neutral-950/70 p-2 sm:p-4 overflow-auto flex justify-center items-start">
        <div 
          className={`h-full transition-all duration-200 flex flex-col bg-white rounded-lg shadow-xl overflow-hidden border border-neutral-800 ${getViewportWidth()}`}
        >
          {/* Simulated Browser Address Bar for Realistic Previewing */}
          <div className="h-6 bg-neutral-200 px-3 flex items-center gap-2 select-none shrink-0 border-b border-neutral-300">
            <div className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-red-400 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block"></span>
            </div>
            <div className="flex-1 max-w-sm mx-auto bg-white rounded px-2 text-[10px] text-neutral-500 truncate text-center font-mono">
              about:blank (sandbox)
            </div>
          </div>

          <iframe
            key={key}
            ref={iframeRef}
            srcDoc={finalHtml}
            title="HTML Live Canvas Sandbox"
            sandbox="allow-scripts allow-modals allow-forms allow-same-origin"
            className="w-full flex-1 border-0 bg-white"
          />
        </div>
      </div>

      {/* Console Drawer */}
      {showConsole && (
        <div className="h-44 border-t border-neutral-800 bg-neutral-950 flex flex-col font-mono text-xs">
          <div className="flex items-center justify-between px-3 py-1.5 bg-neutral-900 border-b border-neutral-800 text-[11px] text-neutral-400">
            <div className="flex items-center gap-2">
              <Terminal className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-semibold text-neutral-300">Preview Console</span>
              <span>·</span>
              <span className="tabular-nums">{logs.length} messages</span>
            </div>
            <button
              onClick={handleClearLogs}
              title="Clear Console Output"
              className="flex items-center gap-1 text-neutral-400 hover:text-neutral-200"
            >
              <Trash2 className="w-3 h-3" />
              <span>Clear</span>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {logs.length === 0 ? (
              <div className="text-neutral-600 italic py-2 px-1">
                Console output is clear. Call <code>console.log()</code> or trigger events to inspect.
              </div>
            ) : (
              logs.map((log) => (
                <div
                  key={log.id}
                  className={`flex items-start gap-2 py-0.5 px-1.5 rounded ${
                    log.type === 'error'
                      ? 'bg-red-950/40 text-red-300'
                      : log.type === 'warn'
                      ? 'bg-amber-950/40 text-amber-300'
                      : 'text-neutral-300'
                  }`}
                >
                  <span className="text-neutral-500 text-[10px] shrink-0 tabular-nums">
                    [{log.timestamp}]
                  </span>
                  <span className="font-semibold text-[10px] uppercase shrink-0">
                    {log.type}:
                  </span>
                  <pre className="flex-1 whitespace-pre-wrap break-all font-mono text-xs">
                    {log.content}
                  </pre>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
