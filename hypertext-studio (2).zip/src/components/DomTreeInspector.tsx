import React, { useState } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  Layers, 
  Search, 
  Maximize2, 
  Minimize2,
  Code
} from 'lucide-react';
import { extractDomTree } from '../utils/htmlFormatter';
import { DomNodeInfo } from '../types/htmlStudio';

interface DomTreeInspectorProps {
  html: string;
}

export const DomTreeInspector: React.FC<DomTreeInspectorProps> = ({ html }) => {
  const domTree = extractDomTree(html);
  const [selectedNode, setSelectedNode] = useState<DomNodeInfo | null>(domTree);
  const [filterText, setFilterText] = useState('');

  if (!domTree) {
    return (
      <div className="flex-1 flex items-center justify-center p-8 bg-neutral-950 text-neutral-500 text-sm">
        Unable to parse DOM tree. Please verify that your HTML contains valid elements.
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden bg-neutral-950">
      {/* Tree View Pane */}
      <div className="flex-1 flex flex-col border-r border-neutral-800 bg-neutral-950">
        <div className="p-3 border-b border-neutral-800 bg-neutral-900/60 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-neutral-200">DOM Hierarchy Inspector</span>
          </div>

          <div className="relative w-48 sm:w-64">
            <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-2.5 top-2" />
            <input
              type="text"
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              placeholder="Filter by tag or class..."
              className="w-full pl-8 pr-2.5 py-1 bg-neutral-950 border border-neutral-800 rounded text-xs text-neutral-200 outline-none focus:border-blue-500"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 font-mono text-xs">
          <TreeNode
            node={domTree}
            selectedNode={selectedNode}
            onSelect={setSelectedNode}
            filterText={filterText}
          />
        </div>
      </div>

      {/* Node Inspector Details */}
      <div className="w-full md:w-80 lg:w-96 flex flex-col bg-neutral-900/40 border-t md:border-t-0 border-neutral-800 p-4 overflow-y-auto">
        <h3 className="text-xs font-semibold text-neutral-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Code className="w-3.5 h-3.5 text-blue-400" />
          <span>Element Properties</span>
        </h3>

        {selectedNode ? (
          <div className="space-y-4 text-xs font-mono">
            <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
              <div className="text-neutral-500 text-[10px] uppercase font-sans mb-1">Tag Name</div>
              <div className="text-blue-400 font-bold text-sm">
                &lt;{selectedNode.tagName}&gt;
              </div>
            </div>

            {selectedNode.idAttr && (
              <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-500 text-[10px] uppercase font-sans mb-1">Element ID (#)</div>
                <div className="text-emerald-400">#{selectedNode.idAttr}</div>
              </div>
            )}

            {selectedNode.className && (
              <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-500 text-[10px] uppercase font-sans mb-1">Class List (.)</div>
                <div className="text-purple-400 break-words">{selectedNode.className}</div>
              </div>
            )}

            <div>
              <div className="text-neutral-500 text-[10px] uppercase font-sans mb-1.5">
                Attributes ({Object.keys(selectedNode.attributes).length})
              </div>
              {Object.keys(selectedNode.attributes).length === 0 ? (
                <div className="text-neutral-600 italic">No custom attributes defined</div>
              ) : (
                <div className="space-y-1.5">
                  {Object.entries(selectedNode.attributes).map(([k, v]) => (
                    <div
                      key={k}
                      className="p-2 rounded bg-neutral-900 border border-neutral-800 flex flex-col gap-0.5"
                    >
                      <span className="text-amber-400 font-semibold">{k}</span>
                      <span className="text-neutral-300 break-all">"{v}"</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {selectedNode.textContent && (
              <div className="p-3 rounded-lg bg-neutral-900 border border-neutral-800">
                <div className="text-neutral-500 text-[10px] uppercase font-sans mb-1">Inner Text Snippet</div>
                <div className="text-neutral-300 italic font-sans text-xs">
                  "{selectedNode.textContent}"
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-neutral-500 text-xs italic">
            Select any node in the tree to view its attributes.
          </div>
        )}
      </div>
    </div>
  );
};

interface TreeNodeProps {
  node: DomNodeInfo;
  selectedNode: DomNodeInfo | null;
  onSelect: (node: DomNodeInfo) => void;
  filterText: string;
}

const TreeNode: React.FC<TreeNodeProps> = ({
  node,
  selectedNode,
  onSelect,
  filterText,
}) => {
  const [open, setOpen] = useState(true);

  const hasChildren = node.children && node.children.length > 0;
  const isSelected = selectedNode?.id === node.id;

  const matchesFilter =
    !filterText ||
    node.tagName.toLowerCase().includes(filterText.toLowerCase()) ||
    (node.className && node.className.toLowerCase().includes(filterText.toLowerCase())) ||
    (node.idAttr && node.idAttr.toLowerCase().includes(filterText.toLowerCase()));

  return (
    <div className={`pl-4 ${matchesFilter ? 'opacity-100' : 'opacity-40'}`}>
      <div
        onClick={() => onSelect(node)}
        className={`flex items-center gap-1.5 py-1 px-1.5 rounded cursor-pointer transition-colors ${
          isSelected
            ? 'bg-blue-600/20 text-blue-300 border border-blue-500/30'
            : 'hover:bg-neutral-900 text-neutral-300'
        }`}
      >
        {hasChildren ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setOpen(!open);
            }}
            className="p-0.5 text-neutral-500 hover:text-neutral-300"
          >
            {open ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
        ) : (
          <span className="w-4 inline-block" />
        )}

        <span className="text-blue-400 font-semibold">&lt;{node.tagName}&gt;</span>

        {node.idAttr && (
          <span className="text-emerald-400 text-[11px]">#{node.idAttr}</span>
        )}

        {node.className && (
          <span className="text-purple-400 text-[11px] truncate max-w-[140px]">
            .{node.className.split(' ').join('.')}
          </span>
        )}

        {node.textContent && (
          <span className="text-neutral-500 text-[11px] truncate max-w-[150px] font-sans">
            "{node.textContent}"
          </span>
        )}
      </div>

      {hasChildren && open && (
        <div className="border-l border-neutral-800/80 ml-2">
          {node.children.map((child) => (
            <TreeNode
              key={child.id}
              node={child}
              selectedNode={selectedNode}
              onSelect={onSelect}
              filterText={filterText}
            />
          ))}
        </div>
      )}
    </div>
  );
};
