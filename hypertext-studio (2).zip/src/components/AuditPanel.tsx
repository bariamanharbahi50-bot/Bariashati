import React from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  XCircle, 
  Info, 
  Wand2, 
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { LintIssue } from '../types/htmlStudio';
import { applyQuickFix } from '../utils/htmlValidator';

interface AuditPanelProps {
  issues: LintIssue[];
  html: string;
  onUpdateHtml: (newHtml: string) => void;
}

export const AuditPanel: React.FC<AuditPanelProps> = ({
  issues,
  html,
  onUpdateHtml,
}) => {
  const errors = issues.filter((i) => i.type === 'error');
  const warnings = issues.filter((i) => i.type === 'warning');
  const infos = issues.filter((i) => i.type === 'info');

  const fixableCount = issues.filter((i) => i.fixable).length;

  const handleFixIssue = (fixAction?: string) => {
    if (!fixAction) return;
    const fixed = applyQuickFix(html, fixAction);
    onUpdateHtml(fixed);
  };

  const handleFixAll = () => {
    let current = html;
    issues.forEach((i) => {
      if (i.fixable && i.fixAction) {
        current = applyQuickFix(current, i.fixAction);
      }
    });
    onUpdateHtml(current);
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-y-auto bg-neutral-950 p-4 sm:p-6">
      <div className="max-w-4xl mx-auto w-full space-y-6">
        {/* Header Summary Strip */}
        <div className="flex flex-wrap items-center justify-between gap-4 p-5 rounded-xl bg-neutral-900 border border-neutral-800">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <ShieldCheck className="w-5 h-5 text-blue-400" />
              <h2 className="text-lg font-bold text-neutral-100">
                Standards, Accessibility &amp; SEO Audit
              </h2>
            </div>
            <p className="text-xs text-neutral-400">
              Real-time conformance checks against W3C HTML5 recommendations and WCAG accessibility standards.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {fixableCount > 0 && (
              <button
                onClick={handleFixAll}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-colors shadow-sm"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Fix All Automatically ({fixableCount})</span>
              </button>
            )}
          </div>
        </div>

        {/* Metric Badges */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-4 rounded-lg bg-neutral-900/60 border border-neutral-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-red-950/50 border border-red-800/40 flex items-center justify-center text-red-400">
              <XCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xl font-bold font-mono tabular-nums text-neutral-100">
                {errors.length}
              </div>
              <div className="text-xs text-neutral-400">Errors (Critical a11y)</div>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-neutral-900/60 border border-neutral-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-amber-950/50 border border-amber-800/40 flex items-center justify-center text-amber-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xl font-bold font-mono tabular-nums text-neutral-100">
                {warnings.length}
              </div>
              <div className="text-xs text-neutral-400">Warnings (Standards)</div>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-neutral-900/60 border border-neutral-800 flex items-center gap-3">
            <div className="w-9 h-9 rounded-md bg-blue-950/50 border border-blue-800/40 flex items-center justify-center text-blue-400">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xl font-bold font-mono tabular-nums text-neutral-100">
                {infos.length}
              </div>
              <div className="text-xs text-neutral-400">Advisories (SEO &amp; Best Practices)</div>
            </div>
          </div>
        </div>

        {/* Issue Cards */}
        <div className="space-y-3">
          {issues.length === 0 ? (
            <div className="p-8 rounded-xl bg-emerald-950/20 border border-emerald-800/40 text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
              <h3 className="text-base font-semibold text-emerald-300">
                Exemplary HTML5 Conformance!
              </h3>
              <p className="text-xs text-emerald-400/80 max-w-md mx-auto">
                No syntax omissions, accessibility violations, or missing meta tags were found in your document.
              </p>
            </div>
          ) : (
            issues.map((issue) => (
              <div
                key={issue.id}
                className="p-4 rounded-lg bg-neutral-900 border border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-3 flex-1">
                  {issue.type === 'error' && (
                    <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  )}
                  {issue.type === 'warning' && (
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  )}
                  {issue.type === 'info' && (
                    <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  )}

                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-neutral-200">
                        {issue.category}
                      </span>
                      <span className="text-neutral-500">·</span>
                      <span className="text-neutral-400">{issue.message}</span>
                    </div>
                  </div>
                </div>

                {issue.fixable && issue.fixAction && (
                  <button
                    onClick={() => handleFixIssue(issue.fixAction)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-blue-400 hover:text-blue-300 border border-neutral-700 text-xs font-medium transition-colors shrink-0"
                  >
                    <Wand2 className="w-3 h-3" />
                    <span>Quick Fix</span>
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
