/**
 * Types for HyperText Studio
 */

export interface Template {
  id: string;
  name: string;
  category: 'Modern Layouts' | 'Forms & Inputs' | 'Components' | 'Graphics & Media' | 'Interactive';
  description: string;
  html: string;
  css?: string;
  js?: string;
}

export type TagCategory =
  | 'Document Metadata'
  | 'Sectioning'
  | 'Content Grouping'
  | 'Text Semantics'
  | 'Embedded & Media'
  | 'Tabular Data'
  | 'Forms & Controls'
  | 'Interactive Elements'
  | 'Web Components';

export interface HtmlTagInfo {
  tag: string;
  name: string;
  category: TagCategory;
  description: string;
  selfClosing: boolean;
  commonAttributes: string[];
  snippet: string;
  mdnSlug: string;
  a11yNote?: string;
  isDeprecated?: boolean;
}

export interface LintIssue {
  id: string;
  type: 'error' | 'warning' | 'info';
  category: 'Syntax' | 'Accessibility' | 'SEO' | 'Best Practice';
  message: string;
  line?: number;
  fixable?: boolean;
  fixAction?: string;
}

export interface ConsoleLogMessage {
  id: string;
  type: 'log' | 'info' | 'warn' | 'error';
  content: string;
  timestamp: string;
}

export type ViewportMode = 'responsive' | 'desktop' | 'tablet' | 'mobile';

export interface DomNodeInfo {
  id: string;
  tagName: string;
  className?: string;
  idAttr?: string;
  textContent?: string;
  attributes: Record<string, string>;
  children: DomNodeInfo[];
}
