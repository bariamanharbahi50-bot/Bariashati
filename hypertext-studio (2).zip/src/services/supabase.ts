import { createClient } from '@supabase/supabase-js';

export const SUPABASE_URL = "https://jkdyfkthsnemvdnqenlz.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_51qenmKrvkBI2MdFe1CTGQ_FQZVxW6W";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

export interface LocalPost {
  id: string;
  title: string;
  description?: string;
  media_url?: string;
  latitude: number;
  longitude: number;
  created_at?: string;
  category?: 'news' | 'event' | 'alert' | 'market' | 'general';
  distance_meters?: number;
}

export const ADD_CATEGORY_SQL = `ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'general';`;

export const SUPABASE_SQL_MIGRATION = `-- ⚠️ यदि 'category' कॉलम का एरर आ रहा है, तो बस यह एक लाइन चलाएं:
ALTER TABLE public.posts ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'general';

-- 1. 'posts' टेबल निर्माण (यदि पहले से नहीं बनी है)
CREATE TABLE IF NOT EXISTS public.posts (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    description TEXT,
    media_url TEXT,
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    category TEXT DEFAULT 'general',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;

-- Allow public read access
CREATE POLICY "Public read posts" ON public.posts
    FOR SELECT USING (true);

-- Allow public insert access
CREATE POLICY "Public insert posts" ON public.posts
    FOR INSERT WITH CHECK (true);

-- Allow public delete access
CREATE POLICY "Public delete posts" ON public.posts
    FOR DELETE USING (true);

-- 2. Create the get_nearby_posts RPC function using the Haversine formula
CREATE OR REPLACE FUNCTION public.get_nearby_posts(
    user_lat DOUBLE PRECISION,
    user_lng DOUBLE PRECISION,
    radius_meters DOUBLE PRECISION DEFAULT 5000
)
RETURNS TABLE (
    id UUID,
    title TEXT,
    description TEXT,
    media_url TEXT,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    category TEXT,
    created_at TIMESTAMPTZ,
    distance_meters DOUBLE PRECISION
)
LANGUAGE sql
SECURITY DEFINER
AS $$
    SELECT 
        p.id,
        p.title,
        p.description,
        p.media_url,
        p.latitude,
        p.longitude,
        p.category,
        p.created_at,
        ROUND((
            6371000 * acos(
                LEAST(1.0, GREATEST(-1.0, 
                    cos(radians(user_lat)) * cos(radians(p.latitude)) * 
                    cos(radians(p.longitude) - radians(user_lng)) + 
                    sin(radians(user_lat)) * sin(radians(p.latitude))
                ))
            )
        )::numeric, 1)::DOUBLE PRECISION AS distance_meters
    FROM public.posts p
    WHERE (
        6371000 * acos(
            LEAST(1.0, GREATEST(-1.0, 
                cos(radians(user_lat)) * cos(radians(p.latitude)) * 
                cos(radians(p.longitude) - radians(user_lng)) + 
                sin(radians(user_lat)) * sin(radians(p.latitude))
            ))
        )
    ) <= radius_meters
    ORDER BY distance_meters ASC;
$$;

-- 3. Storage bucket instructions:
-- In Supabase Dashboard -> Storage:
-- Create a public bucket named 'posts-media'

-- 4. 'likes' टेबल निर्माण (Like फीचर हेतु)
CREATE TABLE IF NOT EXISTS public.likes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_id UUID REFERENCES public.posts(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read likes" ON public.likes FOR SELECT USING (true);
CREATE POLICY "Public insert likes" ON public.likes FOR INSERT WITH CHECK (true);
CREATE POLICY "Public delete likes" ON public.likes FOR DELETE USING (true);

-- 5. 'comments' टेबल निर्माण (Comment फीचर हेतु)
CREATE TABLE IF NOT EXISTS public.comments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    post_id UUID REFERENCES public.posts(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read comments" ON public.comments FOR SELECT USING (true);
CREATE POLICY "Public insert comments" ON public.comments FOR INSERT WITH CHECK (true);
CREATE POLICY "Public delete comments" ON public.comments FOR DELETE USING (true);
`;

// Calculate Haversine distance between two coordinates in meters
export function calculateHaversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371e3; // metres
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}
