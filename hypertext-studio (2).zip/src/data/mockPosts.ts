import { LocalPost } from '../services/supabase';

export const INITIAL_DEMO_POSTS: LocalPost[] = [
  {
    id: 'demo-1',
    title: 'ताज़ा फल एवं सब्जियों की साप्ताहिक मंडी',
    description: 'मेन मार्केट चौराहे पर आज ताज़ा जैविक सब्जियाँ और फल रियायती दरों पर उपलब्ध हैं। शाम 7 बजे तक खुला है।',
    media_url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
    latitude: 28.6139,
    longitude: 77.2090,
    category: 'market',
    created_at: new Date(Date.now() - 1000 * 60 * 35).toISOString(),
  },
  {
    id: 'demo-2',
    title: 'सामुदायिक पार्क में निःशुल्क योग शिविर कल सुबह',
    description: 'वार्ड 14 के शांति उपवन पार्क में कल प्रातः 6:00 बजे से योग एवं प्राणायाम सत्र आयोजित किया जाएगा। सभी सादर आमंत्रित हैं।',
    media_url: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=800&q=80',
    latitude: 28.6190,
    longitude: 77.2150,
    category: 'event',
    created_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
  },
  {
    id: 'demo-3',
    title: '⚠️ मुख्य मार्ग पर सीवर लाइन मरम्मत कार्य जारी',
    description: 'स्टेशन रोड पर जल बोर्ड द्वारा पाइपलाइन की मरम्मत चल रही है। कृपया आज शाम तक वैकल्पिक मार्ग (रिंग रोड) का उपयोग करें।',
    media_url: 'https://images.unsplash.com/photo-1584467735871-8e85353a8413?auto=format&fit=crop&w=800&q=80',
    latitude: 28.6250,
    longitude: 77.2010,
    category: 'alert',
    created_at: new Date(Date.now() - 1000 * 60 * 240).toISOString(),
  },
  {
    id: 'demo-4',
    title: 'खोया-पाया: सेंट्रल बैंक के पास चाबियों का गुच्छा मिला',
    description: 'बैंक के एटीएम के पास एक बाइक की चाबी और चाबी का छल्ला मिला है। जिसकी भी हो, वह पहचान बताकर गार्ड रूम से प्राप्त कर ले।',
    media_url: '',
    latitude: 28.6110,
    longitude: 77.2180,
    category: 'general',
    created_at: new Date(Date.now() - 1000 * 60 * 400).toISOString(),
  }
];

export const POPULAR_CITIES = [
  { name: 'दिल्ली (New Delhi)', lat: 28.6139, lng: 77.2090 },
  { name: 'मुंबई (Mumbai)', lat: 19.0760, lng: 72.8777 },
  { name: 'लखनऊ (Lucknow)', lat: 26.8467, lng: 80.9462 },
  { name: 'जयपुर (Jaipur)', lat: 26.9124, lng: 75.7873 },
  { name: 'पटना (Patna)', lat: 25.5941, lng: 85.1376 },
  { name: 'भोपाल (Bhopal)', lat: 23.2599, lng: 77.4126 },
  { name: 'इंदौर (Indore)', lat: 22.7196, lng: 75.8577 },
];
