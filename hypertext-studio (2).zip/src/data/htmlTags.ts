import { HtmlTagInfo } from '../types/htmlStudio';

export const HTML_TAGS: HtmlTagInfo[] = [
  // Document Metadata
  {
    tag: '!DOCTYPE',
    name: 'Document Type Declaration',
    category: 'Document Metadata',
    description: 'Required preamble at the very start of every HTML document. Triggers standards mode.',
    selfClosing: true,
    commonAttributes: [],
    snippet: '<!DOCTYPE html>',
    mdnSlug: 'Doctype'
  },
  {
    tag: 'html',
    name: 'HTML Root Element',
    category: 'Document Metadata',
    description: 'Represents the root of an HTML document; container for all other HTML elements.',
    selfClosing: false,
    commonAttributes: ['lang', 'dir'],
    snippet: '<html lang="en">\n  <head></head>\n  <body></body>\n</html>',
    mdnSlug: 'html',
    a11yNote: 'Always specify the "lang" attribute (e.g. lang="en") so screen readers pronounce content with correct pronunciation.'
  },
  {
    tag: 'head',
    name: 'Document Metadata Container',
    category: 'Document Metadata',
    description: 'Machine-readable metadata container including scripts, stylesheets, title, and meta tags.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<head>\n  <meta charset="UTF-8">\n  <title>Document Title</title>\n</head>',
    mdnSlug: 'head'
  },
  {
    tag: 'title',
    name: 'Document Title',
    category: 'Document Metadata',
    description: 'Defines the document title shown in browser title bars and search engine results.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<title>HyperText Studio</title>',
    mdnSlug: 'title',
    a11yNote: 'Crucial for accessibility: announced first by screen readers when navigating pages.'
  },
  {
    tag: 'meta',
    name: 'Metadata',
    category: 'Document Metadata',
    description: 'Represents document metadata like character set, viewport scale, SEO descriptions, and OpenGraph tags.',
    selfClosing: true,
    commonAttributes: ['charset', 'name', 'content', 'property', 'http-equiv'],
    snippet: '<meta name="viewport" content="width=device-width, initial-scale=1.0">',
    mdnSlug: 'meta'
  },
  {
    tag: 'link',
    name: 'External Resource Link',
    category: 'Document Metadata',
    description: 'Specifies relationships between the current document and an external resource (CSS, fonts, icons).',
    selfClosing: true,
    commonAttributes: ['rel', 'href', 'type', 'media', 'crossorigin'],
    snippet: '<link rel="stylesheet" href="style.css">',
    mdnSlug: 'link'
  },
  {
    tag: 'style',
    name: 'Internal Style',
    category: 'Document Metadata',
    description: 'Contains CSS rules applied directly within the document.',
    selfClosing: false,
    commonAttributes: ['media', 'scoped'],
    snippet: '<style>\n  body { font-family: sans-serif; }\n</style>',
    mdnSlug: 'style'
  },

  // Sectioning
  {
    tag: 'body',
    name: 'Document Body',
    category: 'Sectioning',
    description: 'Represents the main content of an HTML document. Only one body element may exist per document.',
    selfClosing: false,
    commonAttributes: ['class', 'id'],
    snippet: '<body>\n  <main></main>\n</body>',
    mdnSlug: 'body'
  },
  {
    tag: 'header',
    name: 'Header Landmark',
    category: 'Sectioning',
    description: 'Represents introductory content, typically a group of introductory or navigational aids.',
    selfClosing: false,
    commonAttributes: ['class', 'role'],
    snippet: '<header>\n  <h1>Brand Name</h1>\n  <nav></nav>\n</header>',
    mdnSlug: 'header',
    a11yNote: 'Acts as landmark banner if placed directly inside body.'
  },
  {
    tag: 'nav',
    name: 'Navigation Section',
    category: 'Sectioning',
    description: 'Represents a section of a page whose purpose is to provide navigation links.',
    selfClosing: false,
    commonAttributes: ['aria-label'],
    snippet: '<nav aria-label="Main Navigation">\n  <ul>\n    <li><a href="#about">About</a></li>\n  </ul>\n</nav>',
    mdnSlug: 'nav',
    a11yNote: 'Use aria-label if there are multiple nav elements on a single page.'
  },
  {
    tag: 'main',
    name: 'Main Content Landmark',
    category: 'Sectioning',
    description: 'Represents the dominant content of the body of a document. Only one visible main per page.',
    selfClosing: false,
    commonAttributes: ['id'],
    snippet: '<main>\n  <h1>Page Heading</h1>\n  <p>Content goes here...</p>\n</main>',
    mdnSlug: 'main',
    a11yNote: 'Enables screen readers to jump directly to primary content skipping repetitive headers.'
  },
  {
    tag: 'section',
    name: 'Generic Section',
    category: 'Sectioning',
    description: 'Represents a standalone section of a document without a more specific semantic element.',
    selfClosing: false,
    commonAttributes: ['id', 'aria-labelledby'],
    snippet: '<section>\n  <h2>Section Title</h2>\n  <p>Details...</p>\n</section>',
    mdnSlug: 'section',
    a11yNote: 'Should typically contain a natural heading (h2-h6).'
  },
  {
    tag: 'article',
    name: 'Article Element',
    category: 'Sectioning',
    description: 'Represents a self-contained composition intended to be independently distributable (e.g. blog post, card, news item).',
    selfClosing: false,
    commonAttributes: ['class'],
    snippet: '<article>\n  <h2>Story Headline</h2>\n  <p>Story body content...</p>\n</article>',
    mdnSlug: 'article'
  },
  {
    tag: 'aside',
    name: 'Sidebar / Tangential Content',
    category: 'Sectioning',
    description: 'Represents content indirectly related to the document main content (callouts, sidebars, related posts).',
    selfClosing: false,
    commonAttributes: ['aria-label'],
    snippet: '<aside>\n  <h3>Related Articles</h3>\n</aside>',
    mdnSlug: 'aside'
  },
  {
    tag: 'footer',
    name: 'Footer Landmark',
    category: 'Sectioning',
    description: 'Represents a footer for its nearest sectioning content or body.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<footer>\n  <p>&copy; 2026 Company. All rights reserved.</p>\n</footer>',
    mdnSlug: 'footer'
  },
  {
    tag: 'h1',
    name: 'Heading Level 1',
    category: 'Sectioning',
    description: 'Top-level document heading. Every page should have exactly one descriptive h1.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<h1>Main Page Title</h1>',
    mdnSlug: 'Heading_Elements',
    a11yNote: 'Heading hierarchy should strictly descend (h1 -> h2 -> h3) without skipping levels.'
  },
  {
    tag: 'h2',
    name: 'Heading Level 2',
    category: 'Sectioning',
    description: 'Secondary section heading.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<h2>Section Heading</h2>',
    mdnSlug: 'Heading_Elements'
  },
  {
    tag: 'h3',
    name: 'Heading Level 3',
    category: 'Sectioning',
    description: 'Sub-section heading under an h2.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<h3>Sub-section Heading</h3>',
    mdnSlug: 'Heading_Elements'
  },

  // Content Grouping
  {
    tag: 'p',
    name: 'Paragraph',
    category: 'Content Grouping',
    description: 'Represents a paragraph of text.',
    selfClosing: false,
    commonAttributes: ['class'],
    snippet: '<p>A standard paragraph of text.</p>',
    mdnSlug: 'p'
  },
  {
    tag: 'hr',
    name: 'Thematic Break',
    category: 'Content Grouping',
    description: 'Represents a thematic break between paragraph-level elements.',
    selfClosing: true,
    commonAttributes: [],
    snippet: '<hr>',
    mdnSlug: 'hr'
  },
  {
    tag: 'pre',
    name: 'Preformatted Text',
    category: 'Content Grouping',
    description: 'Represents preformatted text presented exactly as written in the HTML source.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<pre><code>const value = 42;</code></pre>',
    mdnSlug: 'pre'
  },
  {
    tag: 'blockquote',
    name: 'Block Quotation',
    category: 'Content Grouping',
    description: 'Indicates that the enclosed text is an extended quotation from another source.',
    selfClosing: false,
    commonAttributes: ['cite'],
    snippet: '<blockquote cite="https://example.com">\n  <p>Quoted wisdom here.</p>\n</blockquote>',
    mdnSlug: 'blockquote'
  },
  {
    tag: 'ul',
    name: 'Unordered List',
    category: 'Content Grouping',
    description: 'Represents an unordered collection of items, typically rendered as bullet points.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<ul>\n  <li>Item One</li>\n  <li>Item Two</li>\n</ul>',
    mdnSlug: 'ul'
  },
  {
    tag: 'ol',
    name: 'Ordered List',
    category: 'Content Grouping',
    description: 'Represents an ordered list of items, rendered with numbers or alphabetic counters.',
    selfClosing: false,
    commonAttributes: ['start', 'reversed', 'type'],
    snippet: '<ol>\n  <li>Step One</li>\n  <li>Step Two</li>\n</ol>',
    mdnSlug: 'ol'
  },
  {
    tag: 'li',
    name: 'List Item',
    category: 'Content Grouping',
    description: 'Represents an item in an ordered or unordered list.',
    selfClosing: false,
    commonAttributes: ['value'],
    snippet: '<li>List item</li>',
    mdnSlug: 'li'
  },
  {
    tag: 'figure',
    name: 'Figure with Caption',
    category: 'Content Grouping',
    description: 'Represents self-contained content, optionally with a caption specified using figcaption.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<figure>\n  <img src="chart.png" alt="Sales growth trend line">\n  <figcaption>Figure 1.1: Annual Growth</figcaption>\n</figure>',
    mdnSlug: 'figure'
  },
  {
    tag: 'figcaption',
    name: 'Figure Caption',
    category: 'Content Grouping',
    description: 'Represents a caption or legend describing the rest of the contents of its parent figure.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<figcaption>Illustration caption description</figcaption>',
    mdnSlug: 'figcaption'
  },
  {
    tag: 'div',
    name: 'Content Division',
    category: 'Content Grouping',
    description: 'Generic container for flow content without semantic meaning. Use semantic elements whenever applicable.',
    selfClosing: false,
    commonAttributes: ['class', 'id'],
    snippet: '<div class="container">\n  <!-- content -->\n</div>',
    mdnSlug: 'div'
  },

  // Text Semantics
  {
    tag: 'a',
    name: 'Anchor / Hyperlink',
    category: 'Text Semantics',
    description: 'Creates a hyperlink to web pages, files, email addresses, or locations in the same page.',
    selfClosing: false,
    commonAttributes: ['href', 'target', 'rel', 'download'],
    snippet: '<a href="https://example.com" target="_blank" rel="noopener noreferrer">Visit Website</a>',
    mdnSlug: 'a',
    a11yNote: 'Always include meaningful anchor text instead of vague words like "click here".'
  },
  {
    tag: 'strong',
    name: 'Strong Importance',
    category: 'Text Semantics',
    description: 'Indicates that its contents have strong importance, seriousness, or urgency.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<strong>Crucial security notice</strong>',
    mdnSlug: 'strong'
  },
  {
    tag: 'em',
    name: 'Stress Emphasis',
    category: 'Text Semantics',
    description: 'Marks text that has stress emphasis, typically altering the pronunciation by screen readers.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<em>emphasized text</em>',
    mdnSlug: 'em'
  },
  {
    tag: 'code',
    name: 'Inline Code',
    category: 'Text Semantics',
    description: 'Displays its contents styled in a monospace font representing computer code.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<code>document.querySelector()</code>',
    mdnSlug: 'code'
  },
  {
    tag: 'time',
    name: 'Date and Time',
    category: 'Text Semantics',
    description: 'Represents a specific period in time or a date, readable by both machines and humans.',
    selfClosing: false,
    commonAttributes: ['datetime'],
    snippet: '<time datetime="2026-11-01T08:00:00Z">November 1, 2026</time>',
    mdnSlug: 'time'
  },
  {
    tag: 'kbd',
    name: 'Keyboard Input',
    category: 'Text Semantics',
    description: 'Represents a span of inline text denoting textual user input from a keyboard.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<kbd>Ctrl</kbd> + <kbd>S</kbd>',
    mdnSlug: 'kbd'
  },
  {
    tag: 'mark',
    name: 'Marked / Highlighted Text',
    category: 'Text Semantics',
    description: 'Represents text that is marked or highlighted for reference or notation purposes.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<mark>searched keyword</mark>',
    mdnSlug: 'mark'
  },

  // Embedded & Media
  {
    tag: 'img',
    name: 'Image Element',
    category: 'Embedded & Media',
    description: 'Embeds an image into the document.',
    selfClosing: true,
    commonAttributes: ['src', 'alt', 'width', 'height', 'loading'],
    snippet: '<img src="photo.jpg" alt="Descriptive visual text" loading="lazy">',
    mdnSlug: 'img',
    a11yNote: 'The "alt" attribute is required. For decorative images, use alt="" with role="presentation".'
  },
  {
    tag: 'video',
    name: 'Video Player',
    category: 'Embedded & Media',
    description: 'Embeds media player which supports video playback into the document.',
    selfClosing: false,
    commonAttributes: ['src', 'controls', 'autoplay', 'loop', 'muted', 'poster'],
    snippet: '<video controls poster="cover.jpg">\n  <source src="movie.mp4" type="video/mp4">\n  <track kind="captions" src="subtitles.vtt" srclang="en">\n</video>',
    mdnSlug: 'video'
  },
  {
    tag: 'audio',
    name: 'Audio Player',
    category: 'Embedded & Media',
    description: 'Used to embed sound content into documents.',
    selfClosing: false,
    commonAttributes: ['src', 'controls', 'autoplay', 'loop', 'muted'],
    snippet: '<audio controls>\n  <source src="audio.mp3" type="audio/mpeg">\n</audio>',
    mdnSlug: 'audio'
  },
  {
    tag: 'iframe',
    name: 'Inline Frame',
    category: 'Embedded & Media',
    description: 'Represents a nested browsing context, embedding another HTML page into the current one.',
    selfClosing: false,
    commonAttributes: ['src', 'title', 'sandbox', 'loading', 'width', 'height'],
    snippet: '<iframe src="https://example.com" title="External embedded widget" sandbox="allow-scripts"></iframe>',
    mdnSlug: 'iframe',
    a11yNote: 'Always provide a meaningful "title" attribute explaining the iframe contents.'
  },
  {
    tag: 'canvas',
    name: 'Bitmap Canvas',
    category: 'Embedded & Media',
    description: 'Container element used to draw graphics on the fly via scripting (JavaScript 2D or WebGL).',
    selfClosing: false,
    commonAttributes: ['width', 'height'],
    snippet: '<canvas id="myCanvas" width="400" height="300"></canvas>',
    mdnSlug: 'canvas'
  },
  {
    tag: 'svg',
    name: 'Scalable Vector Graphics',
    category: 'Embedded & Media',
    description: 'Container for XML-based vector graphics, path definitions, and scalable shapes.',
    selfClosing: false,
    commonAttributes: ['viewBox', 'width', 'height', 'fill', 'xmlns'],
    snippet: '<svg viewBox="0 0 100 100" width="24" height="24">\n  <circle cx="50" cy="50" r="40" stroke="currentColor" fill="none"/>\n</svg>',
    mdnSlug: 'SVG'
  },

  // Tabular Data
  {
    tag: 'table',
    name: 'Table',
    category: 'Tabular Data',
    description: 'Represents tabular data — that is, information presented in a two-dimensional table of rows and columns.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<table>\n  <caption>Monthly Revenue</caption>\n  <thead>\n    <tr><th>Month</th><th>Amount</th></tr>\n  </thead>\n  <tbody>\n    <tr><td>Jan</td><td>$4,200</td></tr>\n  </tbody>\n</table>',
    mdnSlug: 'table'
  },
  {
    tag: 'caption',
    name: 'Table Caption',
    category: 'Tabular Data',
    description: 'Specifies the caption (or title) of a table.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<caption>Quarterly Breakdown</caption>',
    mdnSlug: 'caption'
  },
  {
    tag: 'th',
    name: 'Table Header Cell',
    category: 'Tabular Data',
    description: 'Defines a cell as the header of a group of table cells.',
    selfClosing: false,
    commonAttributes: ['scope', 'colspan', 'rowspan'],
    snippet: '<th scope="col">Header Label</th>',
    mdnSlug: 'th',
    a11yNote: 'Use scope="col" or scope="row" so screen reader cell navigation is unambiguous.'
  },
  {
    tag: 'td',
    name: 'Table Data Cell',
    category: 'Tabular Data',
    description: 'Defines a cell of a table that contains data.',
    selfClosing: false,
    commonAttributes: ['colspan', 'rowspan'],
    snippet: '<td>Cell Data</td>',
    mdnSlug: 'td'
  },

  // Forms & Controls
  {
    tag: 'form',
    name: 'Interactive Form',
    category: 'Forms & Controls',
    description: 'Represents a document section containing interactive controls for submitting information.',
    selfClosing: false,
    commonAttributes: ['action', 'method', 'enctype', 'novalidate'],
    snippet: '<form action="/api/submit" method="POST">\n  <!-- inputs -->\n  <button type="submit">Send</button>\n</form>',
    mdnSlug: 'form'
  },
  {
    tag: 'label',
    name: 'Form Control Label',
    category: 'Forms & Controls',
    description: 'Represents a caption for an item in a user interface.',
    selfClosing: false,
    commonAttributes: ['for'],
    snippet: '<label for="userEmail">Email Address</label>\n<input type="email" id="userEmail">',
    mdnSlug: 'label',
    a11yNote: 'Binding label for="id" increases the clickable touch target of the input.'
  },
  {
    tag: 'input',
    name: 'Input Control',
    category: 'Forms & Controls',
    description: 'Used to create interactive controls for web-based forms to accept data from the user.',
    selfClosing: true,
    commonAttributes: ['type', 'id', 'name', 'value', 'placeholder', 'required', 'pattern', 'min', 'max', 'step'],
    snippet: '<input type="text" id="username" name="username" required>',
    mdnSlug: 'input'
  },
  {
    tag: 'button',
    name: 'Clickable Button',
    category: 'Forms & Controls',
    description: 'Interactive element activated by a user with a mouse, keyboard, finger, or voice command.',
    selfClosing: false,
    commonAttributes: ['type', 'disabled', 'name', 'value'],
    snippet: '<button type="button" class="btn">Click Me</button>',
    mdnSlug: 'button'
  },
  {
    tag: 'select',
    name: 'Select Dropdown',
    category: 'Forms & Controls',
    description: 'Represents a control that provides a menu of options.',
    selfClosing: false,
    commonAttributes: ['id', 'name', 'required', 'multiple'],
    snippet: '<select id="role" name="role">\n  <option value="admin">Admin</option>\n  <option value="user" selected>User</option>\n</select>',
    mdnSlug: 'select'
  },
  {
    tag: 'datalist',
    name: 'Input Autocomplete Options',
    category: 'Forms & Controls',
    description: 'Contains a set of option elements that represent the permissible or recommended options available in other controls.',
    selfClosing: false,
    commonAttributes: ['id'],
    snippet: '<input list="browsers" id="myBrowser">\n<datalist id="browsers">\n  <option value="Chrome">\n  <option value="Firefox">\n  <option value="Safari">\n</datalist>',
    mdnSlug: 'datalist'
  },
  {
    tag: 'textarea',
    name: 'Multi-line Text Input',
    category: 'Forms & Controls',
    description: 'Represents a multi-line plain-text editing control.',
    selfClosing: false,
    commonAttributes: ['id', 'name', 'rows', 'cols', 'maxlength', 'placeholder'],
    snippet: '<textarea id="bio" name="bio" rows="4" placeholder="Tell us about yourself..."></textarea>',
    mdnSlug: 'textarea'
  },
  {
    tag: 'output',
    name: 'Calculation Output',
    category: 'Forms & Controls',
    description: 'Container element into which a site or app can inject the results of a calculation or the outcome of a user action.',
    selfClosing: false,
    commonAttributes: ['for', 'name'],
    snippet: '<output for="rangeInput" name="result">50</output>',
    mdnSlug: 'output'
  },
  {
    tag: 'fieldset',
    name: 'Form Fieldset',
    category: 'Forms & Controls',
    description: 'Used to group several controls as well as labels within a web form.',
    selfClosing: false,
    commonAttributes: ['disabled'],
    snippet: '<fieldset>\n  <legend>Personal Info</legend>\n  <!-- controls -->\n</fieldset>',
    mdnSlug: 'fieldset'
  },
  {
    tag: 'legend',
    name: 'Fieldset Legend',
    category: 'Forms & Controls',
    description: 'Represents a caption for the content of its parent fieldset.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<legend>Contact Preferences</legend>',
    mdnSlug: 'legend'
  },

  // Interactive Elements
  {
    tag: 'dialog',
    name: 'Dialog Box / Modal',
    category: 'Interactive Elements',
    description: 'Represents a dialog box or other interactive component, such as a dismissible alert, inspector, or subwindow.',
    selfClosing: false,
    commonAttributes: ['open'],
    snippet: '<dialog id="myModal">\n  <p>Modal Content</p>\n  <button onclick="this.closest(\'dialog\').close()">Close</button>\n</dialog>',
    mdnSlug: 'dialog',
    a11yNote: 'Always invoke with .showModal() for top-layer positioning and automatic focus trapping.'
  },
  {
    tag: 'details',
    name: 'Disclosure Widget',
    category: 'Interactive Elements',
    description: 'Creates a disclosure widget in which information is visible only when the widget is toggled into an open state.',
    selfClosing: false,
    commonAttributes: ['open'],
    snippet: '<details>\n  <summary>Click to reveal more</summary>\n  <p>Hidden details text...</p>\n</details>',
    mdnSlug: 'details'
  },
  {
    tag: 'summary',
    name: 'Disclosure Summary',
    category: 'Interactive Elements',
    description: 'Specifies a summary, heading, or legend for a details element disclosure box.',
    selfClosing: false,
    commonAttributes: [],
    snippet: '<summary>Frequently Asked Questions</summary>',
    mdnSlug: 'summary'
  },

  // Web Components
  {
    tag: 'template',
    name: 'Content Template',
    category: 'Web Components',
    description: 'Mechanism for holding HTML that is not to be rendered immediately upon page load, but can be instantiated during runtime via JavaScript.',
    selfClosing: false,
    commonAttributes: ['id'],
    snippet: '<template id="card-template">\n  <div class="card">\n    <h3></h3>\n  </div>\n</template>',
    mdnSlug: 'template'
  },
  {
    tag: 'slot',
    name: 'Web Component Slot',
    category: 'Web Components',
    description: 'Placeholder inside a web component that you can fill with your own markup.',
    selfClosing: false,
    commonAttributes: ['name'],
    snippet: '<slot name="card-title">Default Title</slot>',
    mdnSlug: 'slot'
  }
];
