import { Template } from '../types/htmlStudio';

export const STARTER_TEMPLATES: Template[] = [
  {
    id: 'modern-landing',
    name: 'Modern Semantic Showcase',
    category: 'Modern Layouts',
    description: 'Clean semantic HTML5 structure with header, hero section, grid features, testimonial quote, and accessible footer.',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AeroScale — Architectural Engineering</title>
  <style>
    :root {
      --bg: #090a0f;
      --surface: #12151e;
      --border: #1f2433;
      --text: #f0f2f8;
      --text-muted: #8b92a5;
      --accent: #3b82f6;
      --accent-glow: rgba(59, 130, 246, 0.15);
      --font-body: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: var(--bg);
      color: var(--text);
      font-family: var(--font-body);
      line-height: 1.6;
      padding: 0;
    }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.25rem 2.5rem;
      border-bottom: 1px solid var(--border);
      position: sticky;
      top: 0;
      background: rgba(9, 10, 15, 0.85);
      backdrop-filter: blur(12px);
    }
    .logo {
      font-weight: 700;
      font-size: 1.15rem;
      letter-spacing: -0.02em;
      color: var(--text);
      text-decoration: none;
    }
    nav ul {
      display: flex;
      gap: 1.75rem;
      list-style: none;
    }
    nav a {
      color: var(--text-muted);
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.2s;
    }
    nav a:hover { color: var(--text); }
    .btn-primary {
      background: var(--accent);
      color: #fff;
      padding: 0.55rem 1.15rem;
      border-radius: 6px;
      font-size: 0.85rem;
      font-weight: 500;
      text-decoration: none;
      border: none;
      cursor: pointer;
    }
    main {
      max-width: 1080px;
      margin: 0 auto;
      padding: 4rem 1.5rem;
    }
    .hero {
      text-align: center;
      margin-bottom: 5rem;
    }
    .badge {
      display: inline-block;
      font-size: 0.8rem;
      color: var(--accent);
      background: var(--accent-glow);
      border: 1px solid rgba(59, 130, 246, 0.3);
      padding: 0.25rem 0.75rem;
      border-radius: 9999px;
      margin-bottom: 1.25rem;
      font-weight: 500;
    }
    h1 {
      font-size: clamp(2.2rem, 5vw, 3.5rem);
      font-weight: 700;
      letter-spacing: -0.03em;
      line-height: 1.15;
      margin-bottom: 1.25rem;
    }
    .hero p {
      font-size: 1.15rem;
      color: var(--text-muted);
      max-width: 600px;
      margin: 0 auto 2rem auto;
    }
    .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
      margin-bottom: 5rem;
    }
    article.feature-card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 1.75rem;
      transition: transform 0.2s, border-color 0.2s;
    }
    article.feature-card:hover {
      transform: translateY(-2px);
      border-color: #2e364c;
    }
    article h2 {
      font-size: 1.2rem;
      margin-bottom: 0.5rem;
    }
    article p {
      color: var(--text-muted);
      font-size: 0.925rem;
    }
    blockquote {
      background: var(--surface);
      border-left: 3px solid var(--accent);
      padding: 2rem;
      border-radius: 0 8px 8px 0;
      margin-bottom: 4rem;
    }
    blockquote p {
      font-size: 1.25rem;
      font-style: italic;
      margin-bottom: 1rem;
    }
    footer {
      border-top: 1px solid var(--border);
      padding: 2.5rem 1.5rem;
      text-align: center;
      color: var(--text-muted);
      font-size: 0.85rem;
    }
  </style>
</head>
<body>
  <header>
    <a href="#home" class="logo">AeroScale Systems</a>
    <nav aria-label="Main Navigation">
      <ul>
        <li><a href="#capabilities">Capabilities</a></li>
        <li><a href="#infrastructure">Infrastructure</a></li>
        <li><a href="#specifications">Specifications</a></li>
      </ul>
    </nav>
    <button class="btn-primary" onclick="alert('Workspace initialized!')">Launch Console</button>
  </header>

  <main id="home">
    <section class="hero">
      <span class="badge">Next-Generation Structural Simulation</span>
      <h1>Precision Aerodynamics Built on Modern HTML Standards</h1>
      <p>High-fidelity hydrodynamic and structural analysis toolkits orchestrated through native web standards and fluid responsive layout engines.</p>
    </section>

    <section id="capabilities" class="features-grid">
      <article class="feature-card">
        <h2>Semantic Geometry</h2>
        <p>Built with accessible HTML5 elements that browser crawlers and screen readers interpret natively with zero overhead.</p>
      </article>

      <article class="feature-card">
        <h2>Sub-Millisecond Profiling</h2>
        <p>Native DOM tree reconciliation with clean CSS variable styling ensuring 120 FPS render pipelines.</p>
      </article>

      <article class="feature-card">
        <h2>Zero-Dependency Portability</h2>
        <p>Pure standards-compliant code that runs on any modern browser engine without requiring bundlers or runtime bloat.</p>
      </article>
    </section>

    <section id="infrastructure">
      <blockquote>
        <p>"Writing clean, semantic HTML isn't just about syntax—it's the enduring backbone of accessible, resilient web applications."</p>
        <cite>— Engineering Principle #4</cite>
      </blockquote>
    </section>
  </main>

  <footer>
    <p>&copy; 2026 AeroScale Systems Inc. Built with standards-compliant HTML5 and CSS3.</p>
  </footer>
</body>
</html>`
  },
  {
    id: 'accessible-form',
    name: 'Accessible Form & Native Validation',
    category: 'Forms & Inputs',
    description: 'HTML5 form with native constraints, fieldsets, datalist autocomplete, range sliders with output, and real-time validation.',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Developer Registration & Preferences</title>
  <style>
    :root {
      --bg: #0f1117;
      --card: #181b24;
      --border: #282d3d;
      --text: #f1f3f9;
      --text-muted: #8e95ab;
      --primary: #10b981;
      --primary-hover: #059669;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      padding: 2.5rem 1rem;
      display: flex;
      justify-content: center;
    }
    .form-container {
      width: 100%;
      max-width: 580px;
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 2rem;
    }
    h1 {
      font-size: 1.5rem;
      margin-bottom: 0.5rem;
      font-weight: 600;
    }
    .subtitle {
      color: var(--text-muted);
      font-size: 0.875rem;
      margin-bottom: 1.75rem;
    }
    fieldset {
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 1.25rem;
      margin-bottom: 1.5rem;
    }
    legend {
      font-size: 0.85rem;
      font-weight: 600;
      padding: 0 0.5rem;
      color: var(--primary);
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .field-group {
      margin-bottom: 1.15rem;
    }
    .field-group:last-child {
      margin-bottom: 0;
    }
    label {
      display: block;
      font-size: 0.875rem;
      font-weight: 500;
      margin-bottom: 0.35rem;
    }
    input[type="text"],
    input[type="email"],
    input[type="password"],
    select,
    textarea {
      width: 100%;
      padding: 0.65rem 0.85rem;
      background: #11141c;
      border: 1px solid var(--border);
      border-radius: 6px;
      color: var(--text);
      font-size: 0.9rem;
      outline: none;
      transition: border-color 0.15s;
    }
    input:focus, select:focus, textarea:focus {
      border-color: var(--primary);
    }
    .range-wrap {
      display: flex;
      align-items: center;
      gap: 1rem;
    }
    input[type="range"] {
      flex: 1;
      accent-color: var(--primary);
    }
    output {
      font-family: monospace;
      font-weight: 600;
      color: var(--primary);
      min-width: 2.5rem;
    }
    .checkbox-wrap {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      font-size: 0.875rem;
      cursor: pointer;
    }
    .checkbox-wrap input {
      accent-color: var(--primary);
      width: 1.1rem;
      height: 1.1rem;
    }
    .actions {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
      margin-top: 1.75rem;
    }
    button {
      padding: 0.65rem 1.35rem;
      border-radius: 6px;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
      border: 1px solid var(--border);
      background: transparent;
      color: var(--text);
    }
    button[type="submit"] {
      background: var(--primary);
      border-color: var(--primary);
      color: #061e14;
      font-weight: 600;
    }
    button[type="submit"]:hover {
      background: var(--primary-hover);
    }
    .status-box {
      margin-top: 1rem;
      padding: 0.75rem 1rem;
      background: rgba(16, 185, 129, 0.1);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 6px;
      color: var(--primary);
      font-size: 0.85rem;
      display: none;
    }
  </style>
</head>
<body>
  <main class="form-container">
    <h1>Member Registration</h1>
    <p class="subtitle">Complete your verified developer profile using standard HTML5 inputs.</p>

    <form id="regForm" onsubmit="handleFormSubmit(event)">
      <fieldset>
        <legend>Account Credentials</legend>
        
        <div class="field-group">
          <label for="username">Username</label>
          <input 
            type="text" 
            id="username" 
            name="username" 
            required 
            minlength="3" 
            maxlength="24"
            pattern="^[a-zA-Z0-9_-]+$"
            placeholder="e.g. dev_alex"
            autocomplete="username"
          >
        </div>

        <div class="field-group">
          <label for="email">Work Email</label>
          <input 
            type="email" 
            id="email" 
            name="email" 
            required 
            placeholder="alex@company.com"
            autocomplete="email"
          >
        </div>
      </fieldset>

      <fieldset>
        <legend>Stack & Environment</legend>

        <div class="field-group">
          <label for="primaryLang">Primary Technology (Datalist)</label>
          <input 
            list="tech-options" 
            id="primaryLang" 
            name="primaryLang" 
            placeholder="Search or type..."
            required
          >
          <datalist id="tech-options">
            <option value="HTML5 & Web Components">
            <option value="TypeScript & React">
            <option value="Node.js & Express">
            <option value="Rust WebAssembly">
            <option value="Python Data Engineering">
          </datalist>
        </div>

        <div class="field-group">
          <label for="expLevel">Weekly Dedication Hours</label>
          <div class="range-wrap">
            <input 
              type="range" 
              id="expLevel" 
              name="expLevel" 
              min="5" 
              max="60" 
              value="25" 
              step="5"
              oninput="this.nextElementSibling.value = this.value + ' hrs'"
            >
            <output for="expLevel">25 hrs</output>
          </div>
        </div>

        <div class="field-group">
          <label class="checkbox-wrap">
            <input type="checkbox" id="newsletter" name="newsletter" checked>
            <span>Receive weekly specification release summaries</span>
          </label>
        </div>
      </fieldset>

      <div class="actions">
        <button type="reset">Clear</button>
        <button type="submit">Submit Registration</button>
      </div>

      <div id="statusAlert" class="status-box" role="status"></div>
    </form>
  </main>

  <script>
    function handleFormSubmit(e) {
      e.preventDefault();
      const form = e.target;
      const data = new FormData(form);
      const user = data.get('username');
      const email = data.get('email');
      const tech = data.get('primaryLang');
      const hours = data.get('expLevel');
      
      console.log('Form validated successfully:', Object.fromEntries(data.entries()));
      
      const alertBox = document.getElementById('statusAlert');
      alertBox.textContent = 'Account created for ' + user + ' (' + email + ') with focus in ' + tech + ' (' + hours + ' hrs/wk).';
      alertBox.style.display = 'block';
    }
  </script>
</body>
</html>`
  },
  {
    id: 'interactive-dialog-details',
    name: 'Native Dialog Modal & Accordion',
    category: 'Interactive',
    description: 'HTML5 <dialog> element with native showModal() API, backdrop styling, and disclosure <details>/<summary> widgets.',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Native HTML5 Interactive Widgets</title>
  <style>
    :root {
      --bg: #111318;
      --card: #191c24;
      --border: #282e3f;
      --text: #f3f5fa;
      --text-muted: #959cb3;
      --accent: #8b5cf6;
      --accent-hover: #7c3aed;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      padding: 3rem 1.5rem;
      max-width: 760px;
      margin: 0 auto;
      line-height: 1.5;
    }
    h1 {
      font-size: 1.75rem;
      margin-bottom: 0.75rem;
    }
    p.lead {
      color: var(--text-muted);
      margin-bottom: 2rem;
    }
    .trigger-card {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 10px;
      padding: 1.5rem;
      margin-bottom: 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
    }
    button.btn {
      background: var(--accent);
      color: #fff;
      border: none;
      padding: 0.65rem 1.25rem;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s;
    }
    button.btn:hover { background: var(--accent-hover); }

    /* Dialog styling */
    dialog {
      margin: auto;
      background: #1e2230;
      color: var(--text);
      border: 1px solid #3d4660;
      border-radius: 12px;
      padding: 2rem;
      max-width: 480px;
      width: 90%;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6);
    }
    dialog::backdrop {
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(4px);
    }
    dialog h2 {
      margin-bottom: 0.75rem;
    }
    dialog p {
      color: var(--text-muted);
      margin-bottom: 1.5rem;
      font-size: 0.95rem;
    }
    .dialog-actions {
      display: flex;
      justify-content: flex-end;
      gap: 0.75rem;
    }
    .btn-secondary {
      background: #2b3245;
      color: var(--text);
      border: none;
      padding: 0.6rem 1rem;
      border-radius: 6px;
      cursor: pointer;
    }

    /* Details / Summary Accordion */
    .accordion {
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
    }
    details {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 8px;
      overflow: hidden;
      transition: border-color 0.2s;
    }
    details[open] {
      border-color: var(--accent);
    }
    summary {
      padding: 1rem 1.25rem;
      font-weight: 500;
      cursor: pointer;
      user-select: none;
      list-style: none;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    summary::-webkit-details-marker {
      display: none;
    }
    summary::after {
      content: '+';
      font-size: 1.2rem;
      color: var(--text-muted);
      transition: transform 0.2s;
    }
    details[open] summary::after {
      content: '—';
      color: var(--accent);
    }
    .details-content {
      padding: 0 1.25rem 1.25rem 1.25rem;
      color: var(--text-muted);
      font-size: 0.9rem;
      line-height: 1.6;
    }
  </style>
</head>
<body>
  <h1>Native HTML5 Interactive UI</h1>
  <p class="lead">Demonstrating modern browser-native &lt;dialog&gt; and &lt;details&gt; elements requiring zero external libraries.</p>

  <section class="trigger-card">
    <div>
      <h3 style="margin-bottom: 0.25rem;">Modal Architecture</h3>
      <p style="color: var(--text-muted); font-size: 0.85rem;">Opens modal using native HTML5 showModal() method.</p>
    </div>
    <button class="btn" onclick="document.getElementById('demoModal').showModal()">Open Dialog</button>
  </section>

  <!-- HTML5 Dialog Element -->
  <dialog id="demoModal">
    <h2>Native Dialog Box</h2>
    <p>The <code>&lt;dialog&gt;</code> element handles top-layer positioning, focus trapping, and Esc key dismissal out of the box with zero JavaScript hacks.</p>
    <div class="dialog-actions">
      <button class="btn-secondary" onclick="this.closest('dialog').close()">Cancel</button>
      <button class="btn" onclick="console.log('Confirmed action'); this.closest('dialog').close()">Confirm</button>
    </div>
  </dialog>

  <h2 style="font-size: 1.25rem; margin-bottom: 1rem;">Specification Q&amp;A (Details / Summary)</h2>
  <div class="accordion">
    <details open>
      <summary>Why prefer semantic HTML5 tags over div soup?</summary>
      <div class="details-content">
        Semantic tags convey meaning to accessibility assistive technologies (screen readers), automated web crawlers, and search engines while keeping the DOM lightweight and maintainable.
      </div>
    </details>

    <details>
      <summary>How does &lt;dialog&gt; handle accessibility?</summary>
      <div class="details-content">
        When opened via <code>showModal()</code>, the browser automatically traps focus within the dialog, prevents background scroll, and exposes the <code>role="dialog"</code> accessibility tree node.
      </div>
    </details>

    <details>
      <summary>Can form elements automatically close dialogs?</summary>
      <div class="details-content">
        Yes! Using <code>&lt;form method="dialog"&gt;</code> inside a dialog allows button clicks with values to close the dialog and return the <code>returnValue</code> without custom event preventDefault.
      </div>
    </details>
  </div>
</body>
</html>`
  },
  {
    id: 'canvas-svg-graphics',
    name: 'Canvas & SVG Interactive Graphics',
    category: 'Graphics & Media',
    description: 'Dynamic HTML5 <canvas> rendering animated wave particles alongside crisp inline vector <svg> charts.',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HTML5 Canvas & Vector Graphics</title>
  <style>
    :root {
      --bg: #0b0d14;
      --card: #141724;
      --border: #23273c;
      --text: #f0f3fa;
      --text-muted: #8c93a8;
      --cyan: #06b6d4;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      padding: 2.5rem 1.5rem;
      max-width: 900px;
      margin: 0 auto;
    }
    h1 { font-size: 1.75rem; margin-bottom: 0.5rem; }
    p.sub { color: var(--text-muted); margin-bottom: 2rem; }
    .grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 2rem;
    }
    @media (min-width: 768px) {
      .grid { grid-template-columns: 1fr 1fr; }
    }
    .panel {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 1.5rem;
    }
    .panel h2 {
      font-size: 1.1rem;
      margin-bottom: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    canvas {
      width: 100%;
      height: 240px;
      background: #06070a;
      border-radius: 8px;
      border: 1px solid #1a1e2d;
      display: block;
    }
    svg.chart {
      width: 100%;
      height: 240px;
      background: #06070a;
      border-radius: 8px;
      border: 1px solid #1a1e2d;
    }
    .controls {
      display: flex;
      gap: 0.5rem;
      margin-top: 1rem;
    }
    button {
      padding: 0.45rem 0.9rem;
      background: #23283b;
      color: var(--text);
      border: 1px solid var(--border);
      border-radius: 6px;
      font-size: 0.85rem;
      cursor: pointer;
    }
    button:hover { background: #2f364f; }
  </style>
</head>
<body>
  <h1>Interactive Visuals in HTML5</h1>
  <p class="sub">Dynamic high-performance 2D Canvas rendering &amp; scalable vector graphics in pure client code.</p>

  <div class="grid">
    <div class="panel">
      <h2>HTML5 &lt;canvas&gt; Wave Field</h2>
      <canvas id="waveCanvas" width="400" height="240"></canvas>
      <div class="controls">
        <button onclick="toggleAnimation()">Pause / Play</button>
        <button onclick="changeColor()">Shift Hue</button>
      </div>
    </div>

    <div class="panel">
      <h2>Inline Vector &lt;svg&gt; Telemetry</h2>
      <svg class="chart" viewBox="0 0 400 240">
        <defs>
          <linearGradient id="cyanGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#06b6d4" stop-opacity="0.5"/>
            <stop offset="100%" stop-color="#06b6d4" stop-opacity="0.0"/>
          </linearGradient>
        </defs>
        <!-- Grid lines -->
        <line x1="30" y1="40" x2="380" y2="40" stroke="#1f2438" stroke-dasharray="3,3" />
        <line x1="30" y1="100" x2="380" y2="100" stroke="#1f2438" stroke-dasharray="3,3" />
        <line x1="30" y1="160" x2="380" y2="160" stroke="#1f2438" stroke-dasharray="3,3" />
        
        <!-- Shaded Area -->
        <polygon points="40,190 80,140 130,165 190,95 250,115 310,65 370,80 370,210 40,210" fill="url(#cyanGradient)"/>
        
        <!-- Primary Trend Line -->
        <polyline points="40,190 80,140 130,165 190,95 250,115 310,65 370,80" fill="none" stroke="#06b6d4" stroke-width="3" stroke-linecap="round"/>
        
        <!-- Data Markers -->
        <circle cx="190" cy="95" r="5" fill="#38bdf8" stroke="#0b0d14" stroke-width="2"/>
        <circle cx="310" cy="65" r="5" fill="#38bdf8" stroke="#0b0d14" stroke-width="2"/>
        
        <!-- Text labels -->
        <text x="35" y="225" fill="#64748b" font-size="11" font-family="sans-serif">T-0</text>
        <text x="180" y="225" fill="#64748b" font-size="11" font-family="sans-serif">T-50</text>
        <text x="350" y="225" fill="#64748b" font-size="11" font-family="sans-serif">T-100</text>
      </svg>
      <div class="controls">
        <button onclick="console.log('SVG point inspected: (190, 95)')">Inspect Peak</button>
      </div>
    </div>
  </div>

  <script>
    const canvas = document.getElementById('waveCanvas');
    const ctx = canvas.getContext('2d');
    let animating = true;
    let step = 0;
    let hue = 190;

    function render() {
      if (!animating) return;
      ctx.fillStyle = 'rgba(6, 7, 10, 0.2)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.beginPath();
      ctx.lineWidth = 2;
      ctx.strokeStyle = 'hsl(' + hue + ', 85%, 60%)';

      const points = 40;
      for (let i = 0; i <= points; i++) {
        const x = (canvas.width / points) * i;
        const y = 120 + Math.sin((i * 0.3) + step) * 45 + Math.cos((i * 0.15) + step * 0.5) * 20;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      step += 0.04;
      requestAnimationFrame(render);
    }
    render();

    function toggleAnimation() {
      animating = !animating;
      if (animating) render();
      console.log('Animation status:', animating ? 'Running' : 'Paused');
    }

    function changeColor() {
      hue = (hue + 60) % 360;
      console.log('Hue shifted to:', hue);
    }
  </script>
</body>
</html>`
  },
  {
    id: 'data-table-sheet',
    name: 'Accessible Data Table with Sorting',
    category: 'Components',
    description: 'Proper HTML5 table structure with caption, colgroup, thead, tbody, tfoot, and client-side column sorting.',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>High-Performance Data Table</title>
  <style>
    :root {
      --bg: #0d0f17;
      --card: #151824;
      --border: #23283b;
      --text: #f0f2f8;
      --muted: #8c93a8;
      --accent: #3b82f6;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background: var(--bg);
      color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      padding: 3rem 1.5rem;
      max-width: 960px;
      margin: 0 auto;
    }
    h1 { font-size: 1.5rem; margin-bottom: 0.5rem; }
    p.lead { color: var(--muted); margin-bottom: 2rem; font-size: 0.95rem; }
    
    .table-container {
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 10px;
      overflow: hidden;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      text-align: left;
      font-size: 0.9rem;
    }
    caption {
      padding: 1rem 1.25rem;
      font-weight: 600;
      text-align: left;
      background: #11141f;
      border-bottom: 1px solid var(--border);
      font-size: 1rem;
    }
    th {
      background: #181c2b;
      padding: 0.75rem 1rem;
      font-weight: 600;
      color: #cbd5e1;
      border-bottom: 1px solid var(--border);
      cursor: pointer;
      user-select: none;
    }
    th:hover {
      background: #1f2437;
      color: var(--accent);
    }
    td {
      padding: 0.85rem 1rem;
      border-bottom: 1px solid #1c2132;
      color: #e2e8f0;
    }
    tr:last-child td {
      border-bottom: none;
    }
    tr:hover td {
      background: rgba(59, 130, 246, 0.04);
    }
    .num {
      text-align: right;
      font-variant-numeric: tabular-nums;
      font-family: monospace;
    }
    tfoot td {
      background: #11141f;
      font-weight: 600;
      border-top: 1px solid var(--border);
    }
    .status-badge {
      display: inline-block;
      padding: 0.2rem 0.5rem;
      border-radius: 4px;
      font-size: 0.75rem;
      font-weight: 500;
    }
    .status-prod { background: rgba(16, 185, 129, 0.15); color: #34d399; }
    .status-stage { background: rgba(245, 158, 11, 0.15); color: #fbbf24; }
  </style>
</head>
<body>
  <h1>Quarterly Node Cluster Registry</h1>
  <p class="lead">Built using semantic &lt;table&gt;, &lt;colgroup&gt;, &lt;thead&gt;, &lt;tbody&gt;, and &lt;tfoot&gt; elements with interactive client-side sorting.</p>

  <div class="table-container">
    <table id="clusterTable">
      <caption>Active Cloud Node Clusters</caption>
      <colgroup>
        <col style="width: 25%">
        <col style="width: 25%">
        <col style="width: 15%">
        <col style="width: 15%">
        <col style="width: 20%">
      </colgroup>
      <thead>
        <tr>
          <th onclick="sortTable(0)">Cluster Host &#x21C5;</th>
          <th onclick="sortTable(1)">Region &#x21C5;</th>
          <th class="num" onclick="sortTable(2, true)">Cores &#x21C5;</th>
          <th class="num" onclick="sortTable(3, true)">Latency (ms) &#x21C5;</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>us-east-hyper-01</td>
          <td>N. Virginia</td>
          <td class="num">128</td>
          <td class="num">14</td>
          <td><span class="status-badge status-prod">Production</span></td>
        </tr>
        <tr>
          <td>eu-west-hyper-02</td>
          <td>Frankfurt</td>
          <td class="num">96</td>
          <td class="num">28</td>
          <td><span class="status-badge status-prod">Production</span></td>
        </tr>
        <tr>
          <td>ap-south-hyper-03</td>
          <td>Singapore</td>
          <td class="num">64</td>
          <td class="num">62</td>
          <td><span class="status-badge status-stage">Staging</span></td>
        </tr>
        <tr>
          <td>us-west-hyper-04</td>
          <td>Oregon</td>
          <td class="num">256</td>
          <td class="num">11</td>
          <td><span class="status-badge status-prod">Production</span></td>
        </tr>
      </tbody>
      <tfoot>
        <tr>
          <td colspan="2">Total Cores Configured</td>
          <td class="num">544</td>
          <td colspan="2">Avg Latency: ~28.7ms</td>
        </tr>
      </tfoot>
    </table>
  </div>

  <script>
    let sortAsc = true;
    function sortTable(colIndex, isNumeric = false) {
      const table = document.getElementById('clusterTable');
      const tbody = table.querySelector('tbody');
      const rows = Array.from(tbody.querySelectorAll('tr'));
      
      rows.sort((a, b) => {
        let valA = a.children[colIndex].textContent.trim();
        let valB = b.children[colIndex].textContent.trim();
        
        if (isNumeric) {
          valA = parseFloat(valA);
          valB = parseFloat(valB);
          return sortAsc ? valA - valB : valB - valA;
        }
        return sortAsc ? valA.localeCompare(valB) : valB.localeCompare(valA);
      });
      
      sortAsc = !sortAsc;
      tbody.innerHTML = '';
      rows.forEach(r => tbody.appendChild(r));
      console.log('Sorted column index:', colIndex, 'Ascending:', !sortAsc);
    }
  </script>
</body>
</html>`
  }
];
