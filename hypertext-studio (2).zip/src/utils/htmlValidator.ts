import { LintIssue } from '../types/htmlStudio';

export function validateHtml(html: string): LintIssue[] {
  const issues: LintIssue[] = [];

  if (!html.trim()) {
    issues.push({
      id: 'empty-doc',
      type: 'warning',
      category: 'Syntax',
      message: 'Document is currently empty. Select a template or write HTML markup.',
    });
    return issues;
  }

  // 1. DOCTYPE check
  if (!/<!DOCTYPE\s+html>/i.test(html)) {
    issues.push({
      id: 'missing-doctype',
      type: 'warning',
      category: 'Best Practice',
      message: 'Missing standard `<!DOCTYPE html>` declaration. Browsers may fall into quirks mode.',
      fixable: true,
      fixAction: 'insert-doctype',
    });
  }

  // 2. HTML tag & lang attribute
  const htmlTagMatch = html.match(/<html([^>]*)>/i);
  if (htmlTagMatch) {
    const attrs = htmlTagMatch[1];
    if (!/lang\s*=\s*["'][a-zA-Z-]+["']/i.test(attrs)) {
      issues.push({
        id: 'missing-lang',
        type: 'error',
        category: 'Accessibility',
        message: 'The `<html>` element is missing a `lang` attribute (e.g. `<html lang="en">`). Screen readers require this for proper pronunciation.',
        fixable: true,
        fixAction: 'add-lang-attr',
      });
    }
  }

  // 3. Document Title
  if (!/<title[^>]*>[\s\S]*?<\/title>/i.test(html)) {
    issues.push({
      id: 'missing-title',
      type: 'error',
      category: 'SEO',
      message: 'Missing `<title>` element inside `<head>`. Essential for SEO, browser tabs, and screen reader announcements.',
      fixable: true,
      fixAction: 'insert-title',
    });
  }

  // 4. Viewport Meta
  if (!/<meta[^>]+name=["']viewport["'][^>]*>/i.test(html)) {
    issues.push({
      id: 'missing-viewport',
      type: 'warning',
      category: 'Best Practice',
      message: 'Missing `<meta name="viewport" content="width=device-width, initial-scale=1.0">`. Needed for responsive mobile layouts.',
      fixable: true,
      fixAction: 'insert-viewport',
    });
  }

  // 5. Charset Meta
  if (!/<meta[^>]+charset=["']?[a-zA-Z0-9-]+["']?[^>]*>/i.test(html)) {
    issues.push({
      id: 'missing-charset',
      type: 'info',
      category: 'Best Practice',
      message: 'Document lacks explicit `<meta charset="UTF-8">`.',
      fixable: true,
      fixAction: 'insert-charset',
    });
  }

  // 6. Deprecated Tags Check
  const deprecatedTags = ['center', 'font', 'marquee', 'blink', 'strike', 'big', 'frame', 'frameset'];
  deprecatedTags.forEach((tag) => {
    const regex = new RegExp(`<${tag}\\b`, 'i');
    if (regex.test(html)) {
      issues.push({
        id: `deprecated-${tag}`,
        type: 'warning',
        category: 'Best Practice',
        message: `Deprecated HTML tag \`<${tag}>\` detected. Modern web standards recommend CSS layout/styling instead.`,
      });
    }
  });

  // 7. Accessibility: Images missing alt
  const imgRegex = /<img\b([^>]*?)>/gi;
  let imgMatch: RegExpExecArray | null;
  let unlabelledImgCount = 0;
  while ((imgMatch = imgRegex.exec(html)) !== null) {
    const attrs = imgMatch[1];
    if (!/\balt\s*=/i.test(attrs)) {
      unlabelledImgCount++;
    }
  }
  if (unlabelledImgCount > 0) {
    issues.push({
      id: 'missing-img-alt',
      type: 'error',
      category: 'Accessibility',
      message: `${unlabelledImgCount} \`<img>\` tag(s) missing an \`alt\` attribute. Screen readers cannot describe the graphic to visually impaired users.`,
      fixable: true,
      fixAction: 'fix-img-alt',
    });
  }

  // 8. Accessibility: Form inputs missing labels
  const inputRegex = /<input\b([^>]*?)>/gi;
  let inputMatch: RegExpExecArray | null;
  let unlabelledInputCount = 0;
  while ((inputMatch = inputRegex.exec(html)) !== null) {
    const attrs = inputMatch[1];
    const isHidden = /type=["'](hidden|submit|button|reset|image)["']/i.test(attrs);
    if (!isHidden) {
      const hasAriaLabel = /aria-label\s*=/i.test(attrs) || /aria-labelledby\s*=/i.test(attrs);
      const idMatch = attrs.match(/id=["']([^"']+)["']/i);
      let hasAssociatedLabel = false;
      if (idMatch) {
        const id = idMatch[1];
        const labelForRegex = new RegExp(`<label[^>]+for=["']${id}["']`, 'i');
        if (labelForRegex.test(html)) {
          hasAssociatedLabel = true;
        }
      }
      if (!hasAriaLabel && !hasAssociatedLabel) {
        unlabelledInputCount++;
      }
    }
  }
  if (unlabelledInputCount > 0) {
    issues.push({
      id: 'unlabelled-inputs',
      type: 'warning',
      category: 'Accessibility',
      message: `${unlabelledInputCount} input control(s) lack an associated \`<label for="...">\` or \`aria-label\`.`,
    });
  }

  // 9. Heading structure
  const headingLevels: number[] = [];
  const headingRegex = /<h([1-6])\b[^>]*>/gi;
  let hMatch: RegExpExecArray | null;
  while ((hMatch = headingRegex.exec(html)) !== null) {
    headingLevels.push(parseInt(hMatch[1], 10));
  }

  const h1Count = headingLevels.filter((lvl) => lvl === 1).length;
  if (h1Count === 0 && headingLevels.length > 0) {
    issues.push({
      id: 'missing-h1',
      type: 'info',
      category: 'SEO',
      message: 'Document contains subheadings (h2–h6) but has no top-level `<h1>`.',
    });
  } else if (h1Count > 1) {
    issues.push({
      id: 'multiple-h1',
      type: 'info',
      category: 'Best Practice',
      message: `Document has ${h1Count} \`<h1>\` tags. While valid in HTML5, having a single main \`<h1>\` is recommended for SEO and screen reader navigation.`,
    });
  }

  // Check skipped levels (e.g. h1 then h3)
  for (let i = 0; i < headingLevels.length - 1; i++) {
    if (headingLevels[i + 1] > headingLevels[i] + 1) {
      issues.push({
        id: `skipped-heading-${i}`,
        type: 'warning',
        category: 'Accessibility',
        message: `Heading level skipped: \`<h${headingLevels[i]}>\` is immediately followed by \`<h${headingLevels[i + 1]}>\`. Maintain sequential order for assistive navigation.`,
      });
      break;
    }
  }

  // 10. Links with no text / empty links
  const emptyLinks = html.match(/<a\b[^>]*>\s*<\/a>/gi);
  if (emptyLinks && emptyLinks.length > 0) {
    issues.push({
      id: 'empty-links',
      type: 'error',
      category: 'Accessibility',
      message: `${emptyLinks.length} empty \`<a>\` link(s) found. Links require accessible text or an \`aria-label\`.`,
    });
  }

  return issues;
}

export function applyQuickFix(html: string, fixAction: string): string {
  let updated = html;

  switch (fixAction) {
    case 'insert-doctype':
      if (!/<!DOCTYPE\s+html>/i.test(updated)) {
        updated = `<!DOCTYPE html>\n` + updated;
      }
      break;

    case 'add-lang-attr':
      updated = updated.replace(/<html(?![^>]*\blang=)/i, '<html lang="en"');
      break;

    case 'insert-title':
      if (/<head>/i.test(updated)) {
        updated = updated.replace(/<head>/i, '<head>\n  <title>Document</title>');
      } else {
        updated = updated.replace(/<html[^>]*>/i, '$&\n<head>\n  <title>Document</title>\n</head>');
      }
      break;

    case 'insert-viewport':
      if (/<head>/i.test(updated)) {
        updated = updated.replace(/<head>/i, '<head>\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">');
      }
      break;

    case 'insert-charset':
      if (/<head>/i.test(updated)) {
        updated = updated.replace(/<head>/i, '<head>\n  <meta charset="UTF-8">');
      }
      break;

    case 'fix-img-alt':
      updated = updated.replace(/<img\b(?![^>]*\balt=)([^>]*?)>/gi, '<img$1 alt="">');
      break;

    default:
      break;
  }

  return updated;
}
