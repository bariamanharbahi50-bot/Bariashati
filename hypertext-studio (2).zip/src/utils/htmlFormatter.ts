import { DomNodeInfo } from '../types/htmlStudio';

/**
 * Format HTML code with clean 2-space indentation
 */
export function formatHtml(html: string): string {
  let formatted = '';
  let indent = 0;
  const tab = '  ';

  // Normalize lines and trim
  const clean = html
    .replace(/>\s*</g, '><')
    .replace(/<!DOCTYPE\s+html>/gi, '<!DOCTYPE html>\n');

  // Regex to match tags and non-tag content
  const tokens = clean.split(/(<[^>]+>)/g).filter(Boolean);

  const voidTags = new Set([
    'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
    'link', 'meta', 'param', 'source', 'track', 'wbr', '!doctype'
  ]);

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i].trim();
    if (!token) continue;

    if (token.startsWith('</')) {
      // Closing tag: decrease indent first
      indent = Math.max(0, indent - 1);
      formatted += (formatted.endsWith('\n') ? '' : '\n') + tab.repeat(indent) + token + '\n';
    } else if (token.startsWith('<') && !token.startsWith('<!--') && !token.endsWith('/>')) {
      const tagNameMatch = token.match(/<([a-zA-Z0-9-]+)/);
      const tagName = tagNameMatch ? tagNameMatch[1].toLowerCase() : '';

      if (voidTags.has(tagName) || token.toLowerCase().startsWith('<!doctype')) {
        // Void/Self-closing tag
        formatted += (formatted.endsWith('\n') ? '' : '\n') + tab.repeat(indent) + token + '\n';
      } else {
        // Opening tag: print and increase indent
        formatted += (formatted.endsWith('\n') ? '' : '\n') + tab.repeat(indent) + token + '\n';
        indent++;
      }
    } else if (token.startsWith('<!--')) {
      // Comment
      formatted += (formatted.endsWith('\n') ? '' : '\n') + tab.repeat(indent) + token + '\n';
    } else {
      // Text content
      formatted += tab.repeat(indent) + token + '\n';
    }
  }

  return formatted.trim();
}

/**
 * Minify HTML code
 */
export function minifyHtml(html: string): string {
  return html
    .replace(/<!--[\s\S]*?-->/g, '') // remove comments
    .replace(/>\s+</g, '><')         // remove whitespace between tags
    .replace(/\s{2,}/g, ' ')        // collapse multiple spaces into one
    .trim();
}

/**
 * Convert HTML entities
 */
export function encodeHtmlEntities(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

export function decodeHtmlEntities(str: string): string {
  const doc = new DOMParser().parseFromString(str, 'text/html');
  return doc.documentElement.textContent || '';
}

/**
 * Parse HTML into an inspectable DOM Node Tree
 */
export function extractDomTree(html: string): DomNodeInfo | null {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    let counter = 0;
    function walk(node: Element): DomNodeInfo {
      counter++;
      const attrs: Record<string, string> = {};
      for (let i = 0; i < node.attributes.length; i++) {
        const a = node.attributes[i];
        attrs[a.name] = a.value;
      }

      const childNodes = Array.from(node.children).map((child) => walk(child));
      const directText = Array.from(node.childNodes)
        .filter((n) => n.nodeType === Node.TEXT_NODE)
        .map((n) => n.textContent?.trim())
        .filter(Boolean)
        .join(' ');

      return {
        id: `node-${counter}-${node.tagName.toLowerCase()}`,
        tagName: node.tagName.toLowerCase(),
        className: node.className || undefined,
        idAttr: node.id || undefined,
        textContent: directText ? directText.slice(0, 40) : undefined,
        attributes: attrs,
        children: childNodes,
      };
    }

    return walk(doc.documentElement);
  } catch {
    return null;
  }
}
